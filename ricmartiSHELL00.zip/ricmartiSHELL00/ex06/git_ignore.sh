git ls-files --others --exclude-standard --ignore
