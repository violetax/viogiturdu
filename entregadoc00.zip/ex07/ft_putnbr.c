/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <viogonza@student.42urduliz.fr>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 15:14:48 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/07 19:02:23 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	return_positive(int nb)
{
	if (nb < 0)
	{
		nb = nb * -1;
		ft_putchar('-');
	}
	return (nb);
}

int	get_length(int nb)
{
	int	length;

	length = 0;
	while (nb)
	{
		nb /= 10;
		length++;
	}
	return (length);
}

int	get_mod(int length)
{
	int	mod;
	int	zeros;

	mod = 1;
	zeros = length - 1;
	while (zeros >= 0)
	{
		mod = mod * 10;
		zeros--;
	}
	return (mod);
}

void	ft_putnbr(int nb)
{
	char	print;
	int		length;
	int		mod;

	nb = return_positive(nb);
	length = get_length(nb);
	mod = get_mod(length);
	while (mod > 1)
	{
		if (mod == 10)
		{
			print = (nb % mod) + 48;
		}
		else
		{
			print = ((nb % mod) / (mod / 10)) + 48 ;
		}
		ft_putchar(print);
		mod /= 10;
	}
}
