#!/bin/bash
# -*- ENCODING: UTF-8 -*-
git log --format=%H -5
