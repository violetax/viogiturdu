/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbonilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 12:17:33 by dbonilla          #+#    #+#             */
/*   Updated: 2022/07/14 18:24:19 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int		i;
	int		mid ;

	i = 0;
	while (i < (size -1))
	{
		if (tab[i] > tab[i + 1])
		{
			mid = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = mid;
			i = 0;
		}
		else
		{
			i++;
		}
	}
}

int main() {

    int a[] = {100, 2, 56, 4, 10, 15, 1, 95, 2};
//    int *b;
    int i = 0;
    int size = 9;

//	b = a;

	printf("ORIGINAL\t\n");
    while (i < size)
    {
        printf("\t%d\n",a[i]);
        i++;
    }

	ft_sort_int_tab(a, size);

	printf("%s\n","-----------------------");

	printf("ORDENADO\t\n");
	i = 0;
    while (i < size)
    {
        printf("\t%d\n",a[i]);
        i++;
    }


return 0;
}
