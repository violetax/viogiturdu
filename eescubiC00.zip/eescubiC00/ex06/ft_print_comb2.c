/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 20:47:28 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/05 18:19:01 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	escribirnum(int num)
{
	int		decenas;
	int		unidades;

	decenas = num / 10;
	unidades = num % 10;
	ft_putchar(decenas + 48);
	ft_putchar(unidades + 48);
}

void	escribir(int num1, int num2)
{
	escribirnum(num1);
	ft_putchar(' ');
	escribirnum(num2);
	if (!(num1 == 98 && num2 == 99))
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_comb2(void)
{
	int		num1;
	int		num2;

	num1 = 0;
	while (num1 <= 98)
	{
		num2 = num1 + 1;
		while (num2 <= 99)
		{
			escribir(num1, num2);
			num2++;
		}
		num1++;
	}
}
