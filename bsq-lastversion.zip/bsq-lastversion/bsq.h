/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 09:22:42 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 19:36:45 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BSQ_H
# define BSQ_H

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>
# include <stdio.h>

char	*ft_ask_for_map(char *msg);
void	ft_looking_for_sol(char *mapname);
void	ft_looking_for_sols(char *mapnames);
void	ft_print_msg(char *msg);
void	ft_print_title(char *mapname);
void	ft_split_mapnames(char *mapn, char *currentm, int *j);
void	ft_find_square(char *mapname);
int		*ft_get_square_size(char file, int *size);
int		*ft_check_map(char file, int *sz, int co[2]);
int		*ft_cli(int *sz, int co[2], unsigned char c, unsigned char *l);
int		*ft_save_map_header(int *sz, unsigned char *line);
int		*ft_line_break(int *sz, int co[2], unsigned char *line);
void	ft_map_ok(char *mapname, int *size);
void	ft_load_map(char **map, char *mapname, int *size);
void	ft_lock_square(char **map, int *size);
void	ft_parse_square(char **map, int *s, int maxs[2][4], int ij[2][2]);
void	ft_print_square(char **map, int *s, int maxs[2][4]);
char	ft_parse_unit(char **map, int *s, int maxs[2][4], int ij[2][2]);
char	ft_check_collision(char **map, int *s, int maxs[2][4], int ij[2][2]);
void	ft_check_inside(char **map, int *s, int ij[2][2]);
void	ft_write_square(char **map, int *size, int maxs[2][4]);

#endif
