/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map_ok.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 19:10:14 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 19:38:35 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_map_ok(char *mapname, int *size)
{
	char	**map;
	int		i;

	map = NULL;
	map = malloc (sizeof(char *) * size[0]);
	i = 0;
	while (i < size[0])
	{
		map[i] = NULL;
		map[i] = malloc(sizeof(char) * size[1]);
		i++;
	}
	ft_load_map(map, mapname, size);
	i = 0;
	while (i < size[0])
	{
		free(map[i]);
		map[i] = NULL;
		i++;
	}
	free(map);
	map = NULL;
}
