/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 09:22:11 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 14:08:38 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	main(int nargs, char **args)
{
	int		i;

	if (nargs == 1)
		ft_looking_for_sols(ft_ask_for_map("File map/s: "));
	else
	{
		i = 1;
		while (i < nargs)
			ft_looking_for_sol(args[i++]);
	}
	return (0);
}
