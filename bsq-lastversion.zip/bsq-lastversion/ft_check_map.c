/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 13:31:20 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 18:12:04 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	*ft_check_map(char f, int *s, int co[2])
{
	unsigned char	c;
	unsigned char	*firstline;

	firstline = NULL;
	firstline = malloc(sizeof(unsigned char) * 42);
	while (read(f, &c, 1))
	{
		s = ft_cli(s, co, c, firstline);
	}
	free(firstline);
	firstline = NULL;
	return (s);
}
