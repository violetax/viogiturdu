/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_square.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 09:12:37 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/19 09:12:38 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_print_square(char **map, int *size, int maxs[2][4])
{
	int		i;
	int		j;
	char	c;

	ft_write_square(map, size, maxs);
	i = 0;
	while (i < size[0])
	{
		j = 0;
		while (j < size[1])
		{
			c = map[i][j];
			write(1, &c, 1);
			j++;
		}
		write (1, &"\n", 1);
		i++;
	}
}
