/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_looking_for_sols.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 09:43:45 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 17:36:59 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_looking_for_sols(char *mapnames)
{
	char	*currentmap;
	int		j;

	currentmap = NULL;
	currentmap = malloc(sizeof(char));
	ft_split_mapnames(mapnames, currentmap, &j);
	if (j > 0)
	{
		currentmap[j] = 0;
		ft_looking_for_sol(currentmap);
	}
	free(currentmap);
	currentmap = NULL;
	free(mapnames);
	mapnames = NULL;
}
