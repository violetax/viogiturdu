/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_line_break.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 18:28:37 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 18:30:57 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	*ft_line_break(int *sz, int coo[2], unsigned char *line)
{
	if (coo[0] == 0)
	{
		sz = ft_save_map_header(sz, line);
	}
	if (coo[0] == 1)
	{
		sz[1] = coo[1];
	}
	if (coo[0] > 1 && sz[1] != coo[1])
	{
		sz[1] = 0;
		return (sz);
	}
	coo[0]++;
	coo[1] = 0;
	return (sz);
}
