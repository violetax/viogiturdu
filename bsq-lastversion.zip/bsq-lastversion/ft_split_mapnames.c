/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_mapnames.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 09:50:04 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 11:25:28 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_split_mapnames(char *mapnames, char *currentmap, int *j)
{
	int	i;

	i = 0;
	*j = 0;
	while (mapnames[i])
	{
		if (mapnames[i] != ' ' && mapnames[i] != '\n')
		{
			currentmap[*j] = mapnames[i];
			*j = *j + 1;
		}
		else
		{
			if (*j > 0)
			{
				currentmap[*j] = 0;
				ft_looking_for_sol(currentmap);
				*j = 0;
			}
		}
		i++;
	}
}
