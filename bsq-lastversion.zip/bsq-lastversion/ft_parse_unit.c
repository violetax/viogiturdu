/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_unit.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 09:38:58 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/19 09:39:00 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	ft_parse_unit(char **map, int *s, int maxs[2][4], int ij[2][2])
{
	maxs[1][0] = 0;
	maxs[1][1] = 0;
	s[2] = 1;
	while ((ij[0][0] + s[2] <= s[0] && ij[0][1] + s[2] <= s[1] && !maxs[1][0])
		&& (map[ij[0][0]][ij[0][1]] != s[4]))
	{
		if (ij[0][0] + s[2] == s[0] || ij[0][1] + s[2] == s[1])
		{
			maxs[1][0] = 1;
			maxs[1][1] = ft_check_collision(map, s, maxs, ij);
		}
		else
		{
			if ((map[ij[0][0]][ij[0][1] + s[2]] == s[4])
				|| (map[ij[0][0] + 1][ij[0][1]] == s[4]))
			{
				maxs[1][0] = 1;
				maxs[1][1] = ft_check_collision(map, s, maxs, ij);
			}
		}
		s[2]++;
	}
	return (maxs[1][1]);
}
