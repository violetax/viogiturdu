/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_save_map_header.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 16:37:33 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/20 19:52:27 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	*ft_save_map_header(int *sz, unsigned char *line)
{
	int	ijk[3];

	ijk[0] = 0;
	while (line[ijk[0]])
		ijk[0]++;
	if (ijk[0] < 4)
	{
		sz[1] = 0;
		return (sz);
	}
	sz[5] = (int)line[--ijk[0]];
	sz[4] = (int)line[--ijk[0]];
	sz[3] = (int)line[--ijk[0]];
	ijk[2] = ijk[0];
	ijk[1] = 0;
	ijk[0] = 1;
	while (ijk[1] < ijk[2] && line[ijk[1]] >= '0' && line[ijk[1]] <= '9')
	{	
		sz[2] = (sz[2] * 10) + (line[ijk[1]] - '0');
		ijk[1]++;
	}
	return (sz);
}
