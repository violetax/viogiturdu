/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_collision.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 10:55:32 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/19 10:55:34 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	ft_check_collision(char **map, int *s, int maxs[2][4], int ij[2][2])
{
	ft_check_inside(map, s, ij);
	if (s[2] > maxs[0][2] - maxs[0][0])
	{
		maxs[0][0] = ij[0][0];
		maxs[0][1] = ij[0][1];
		maxs[0][2] = ij[0][0] + s[2];
		maxs[0][3] = ij[0][1] + s[2];
		return (1);
	}
	return (0);
}
