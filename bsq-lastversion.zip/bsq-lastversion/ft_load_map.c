/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_load_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 19:37:16 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 19:48:59 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_load_map(char **map, char *mapname, int *size)
{
	char	file;
	char	c;
	char	linebreak;
	int		coord[2];

	linebreak = 0;
	coord[0] = -1;
	coord[1] = 0;
	file = open(mapname, 0);
	while (read (file, &c, 1))
	{
		if (linebreak && c != 10)
		{
			map[coord[0]][coord[1]] = c;
			coord[1]++;
		}
		if (c == 10)
		{
			linebreak = 1;
			coord[0]++;
			coord[1] = 0;
		}
	}
	close(file);
	ft_lock_square(map, size);
}
