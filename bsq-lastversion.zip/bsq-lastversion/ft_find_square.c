/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_square.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 12:01:10 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 19:10:26 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                               size[0] x                                    */
/*                               size[1] y                                    */
/*                               size[2] mapwidth                             */
/*                               size[3] .                                    */
/*                               size[4] o                                    */
/*                               size[5] x                                    */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_find_square(char *mapname)
{
	char	file;
	int		*size;

	size = NULL;
	size = malloc(sizeof(unsigned int) * 6);
	size[0] = 0;
	size[1] = 0;
	file = open(mapname, 0);
	if (file != -1)
	{
		size = ft_get_square_size(file, size);
		if (!(size[0] > 0) || !(size[1] > 0))
			ft_print_msg("map error\n");
	}
	else
	{
		ft_print_msg("map error\n");
	}
	close(file);
	if ((size[0] > 0) && (size[1] > 0))
		ft_map_ok(mapname, size);
	free(size);
	size = NULL;
}
