/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ask_for_map.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 09:42:36 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 19:29:52 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	*ft_ask_for_map(char *msg)
{
	unsigned char	i;
	unsigned char	c;
	char			*maps;

	maps = NULL;
	maps = malloc(sizeof(char));
	ft_print_msg(msg);
	i = 0;
	read(1, &c, 1);
	while (c != 10)
	{
		maps[i++] = c;
		read(1, &c, 1);
	}
	maps[i] = 0;
	return (maps);
}
