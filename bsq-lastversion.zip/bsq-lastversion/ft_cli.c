/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cli.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 13:47:58 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 18:30:30 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	*ft_cli(int *sz, int coo[2], unsigned char c, unsigned char *l)
{
	if (c == 10)
	{
		sz = ft_line_break(sz, coo, l);
	}
	else
	{
		if (coo[0] == 0)
		{
			if (c != 10)
				l[coo[1]] = c;
			else
				l[coo[1]] = 0;
		}
		else
		{
			if (c != sz[3] && c != sz[4])
			{
				sz[1] = 0;
				return (sz);
			}
		}
		coo[1]++;
	}
	return (sz);
}
