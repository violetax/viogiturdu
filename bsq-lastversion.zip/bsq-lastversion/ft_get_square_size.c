/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_square_size.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 12:33:20 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/18 17:44:30 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	*ft_get_square_size(char file, int *size)
{
	int	coord[2];

	coord[0] = 0;
	while (coord[0] < 5)
		size[coord[0]++] = 0;
	coord[0] = 0;
	coord[1] = 0;
	size = ft_check_map(file, size, coord);
	size[0] = coord[0] - 1;
	if ((size[0] != size[2] || size[3] == size[4])
		|| (size[3] == size[5] || size[4] == size[5]))
		size[1] = 0;
	return (size);
}
