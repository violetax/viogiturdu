/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_square.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 09:08:45 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/19 09:08:47 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_parse_square(char **map, int *s, int maxs[2][4], int ij[2][2])
{
	char	flagfound;

	flagfound = 0;
	ij[0][0] = 0;
	while (ij[0][0] < s[0])
	{
		ij[0][1] = 0;
		while (ij[0][1] < s[1])
		{
			if (ft_parse_unit(map, s, maxs, ij))
				flagfound = 1;
			ij[0][1]++;
		}
		ij[0][0]++;
	}
	if (flagfound)
		ft_print_square(map, s, maxs);
	else
		ft_print_msg("map error\n");
}
