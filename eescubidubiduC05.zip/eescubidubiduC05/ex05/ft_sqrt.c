/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 10:05:03 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:41:22 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	while (i * i <= nb)
	{
		if (i * i == nb)
			return (i);
		i++;
	}
	return (0);
}

int	main(void)
{
	int	sqr;
	int	i;

	for (i = -1; i < 50000; i++)
	{
		sqr = ft_sqrt(i);
		if (sqr)
			printf("La raiz cuadrada de %d es: %d\n", i, sqr);
	}
}
