/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 15:06:31 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:39:04 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_factorial(int nb)
{
	if (nb < 0)
		return (0);
	if (nb <= 1)
		return (1);
	return (nb * ft_recursive_factorial(nb - 1));
}

int	main(void)
{
	int	n;
	int	i;

	n = 3;
	printf("Factorial de %d: %d\n", n, ft_recursive_factorial(n));
	for (i = -5; i < 10; i++)
	{
		printf("Factorial de %d: %d\n", i, ft_recursive_factorial(i));
	}
}
