/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 19:25:23 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:40:37 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power < 1)
		return (1);
	return (nb * ft_recursive_power(nb, power - 1));
}

int	main(void)
{
	int	i;
	int	j;
	for (i = -5;i < 5; i++)
		for (j= -5;j < 5; j++)
			printf("%d elevado a %d es: %d\n", i, j, ft_recursive_power(i,j));
}
