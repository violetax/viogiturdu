/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 10:14:46 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:41:56 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_is_prime(int nb)
{
	int	i;
	int	cont;

	if (nb <= 1)
		return (0);
	i = 2;
	cont = 1;
	while (i <= nb / 2 && cont)
	{
		if (nb % i == 0)
			cont = 0;
		i++;
	}
	return (cont);
}

int	main(void)
{
	int	i;

	for (i = -1; i < 100; i++)
	{
		if (ft_is_prime(i))
			printf("%d es primo\n", i);
	}
}
