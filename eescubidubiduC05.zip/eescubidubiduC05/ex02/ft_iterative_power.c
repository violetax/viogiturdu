/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 19:07:59 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:40:08 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	pow;
	int	i;

	if (power < 0)
		return (0);
	if (power < 1)
		return (1);
	pow = 1;
	i = 1;
	while (i <= power)
	{
		pow *= nb;
		i++;
	}
	return (pow);
}

int	main(void)
{
	int	i;
	int	j;

	i = 3;
	j = 2;
	for (i = -5;i < 5; i++)
		for (j= -5;j < 5; j++)
			printf("%d elevado a %d es: %d\n", i, j, ft_iterative_power(i,j));
}
