/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 15:03:57 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:38:35 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_factorial(int nb)
{
	int	f;
	int	i;

	if (nb < 0)
		return (0);
	f = 1;
	i = 1;
	while (i <= nb)
	{
		f = f * i;
		i++;
	}
	return (f);
}

int	main(void)
{
	int	n;
	int	i;

	n = 3;
	printf("Factorial de %d: %d\n", n, ft_iterative_factorial(n));
	for (i = -5; i<10;i++)
	{
		printf("Factorial de %d: %d\n", i, ft_iterative_factorial(i));
	}
}
