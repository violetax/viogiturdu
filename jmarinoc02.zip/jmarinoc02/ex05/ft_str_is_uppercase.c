/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 21:23:37 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/19 22:01:25 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int main ()
{
    char    *str1 = "DFLKGLADK";
    char    *str0 = ";lka-0";
    int     ret;

    ret = ft_str_is_uppercase(str1);
    printf("%s DEBE DE SER 1 → y es %d \n", str1, ret);
    ret = ft_str_is_uppercase(str0);
    printf("%s DEBE DE SER 0 → y es %d \n", str0, ret);
}
