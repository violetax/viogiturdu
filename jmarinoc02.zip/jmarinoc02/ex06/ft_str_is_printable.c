/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 17:27:25 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/19 22:05:32 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
it	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= ' ' && str[i] <= '~')
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int main(void)
{
    char    *strNO = "\x01\x05\x0a\x15";
    char    *strSI = "lkjsf, ldka(8457); fdjkg_jf";
    int     ret;

    ret = ft_str_is_printable(strNO);
    printf("%s → %d\n", strNO, ret);

    ret = ft_str_is_printable(strSI);
    printf("%s → %d\n", strSI, ret);
    return (0);
}
