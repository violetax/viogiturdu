/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acuesta- <acuesta-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 17:18:13 by acuesta-          #+#    #+#             */
/*   Updated: 2022/07/19 18:04:13 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_strcmp(char *s1, char *s2)
{
	int	c;

	c = 0;
	while ((s1[c] == s2[c]) && (s1[c]) && (s2[c]))
	c++;
	return (s1[c] - s2[c]);
}

int	main()
{
	char	s1[] = "hola q lo q?";
	char	s2[] = "hola Q lo q?";

	ft_strcmp(s1, s2);
	printf("%d", ft_strcmp(s1, s2));
	return 0;
}
