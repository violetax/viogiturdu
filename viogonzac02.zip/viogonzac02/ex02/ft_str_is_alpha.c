/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 01:18:58 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/18 18:39:00 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < 0x41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}
