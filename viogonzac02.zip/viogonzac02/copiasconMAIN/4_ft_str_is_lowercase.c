/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 16:41:13 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/19 22:01:13 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	islowerc;
	int	range_min_hd;
	int	range_max_hd;
	int	i;

	islowerc = 0;
	range_min_hd = 0x61;
	range_max_hd = 0x7A;
	i = 0;
	while (str[i] != '\0')
	{
		islowerc = str[i];
		if (islowerc < range_min_hd || islowerc > range_max_hd)
		{
			return (0);
		}
		i++;
	}
	return (1);
}

int	main(void)
{
	char	*strminu;
	char	*strother;
	int		ret;

	strminu = "lkadslf";
	strother = "hhhhhhhhh      hhhh";
	ret = ft_str_is_lowercase(strminu);
	printf("%s\n", strminu);
	printf("%d\n", ret);
	ret = ft_str_is_lowercase(strother);
	printf("%s\n", strother);
	printf("%d\n", ret);
}
