#!/bin/bash

source Asksure.fu
source Opte.fu
source Continua.fu

cfiles=( "0_ft_strcpy.c" "1_ft_strncpy.c" "2_ft_str_is_alpha.c" "3_ft_str_is_numeric.c" "4_ft_str_is_lowercase.c" "5_ft_str_is_uppercase.c" "6_ft_str_is_printable.c" "7_ft_strupcase.c" "8_ft_strlowcase.c" "9_ft_strcapitalize.c" "10_ft_strlcpy.c" )

for cf in ${cfiles[@]} 
do
	vim -c "set nonumber" ${cf} 
	continua
done	

