#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 0x41 && str[i] <= 0x5A)
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char	str[] = "hola QUE TAL ESTAS???? AQUI DENTRO de este SITIO??";
	printf("%s\n", ft_strlowcase(str));
	return (0);
}
