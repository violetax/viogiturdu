/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghurtado <ghurtado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 18:28:31 by ghurtado          #+#    #+#             */
/*   Updated: 2022/07/19 13:19:00 by ghurtado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	i;
	int	j;

	i = (argc - 1);
	while (i > 0)
	{
		j = -1;
		while (argv[i][j++])
			write(1, &argv[i][j], 1);
		write(1, "\n", 1);
		i--;
	}
	return (0);
}
