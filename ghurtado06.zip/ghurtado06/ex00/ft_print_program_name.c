/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ghurtado <ghurtado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 18:28:24 by ghurtado          #+#    #+#             */
/*   Updated: 2022/07/19 10:56:57 by ghurtado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	i;

	i = -1;
	if (argc == 1)
	{
		while (argv[0][++i])
			write(1, &argv[0][i], 1);
		write (1, "\n", 1);
	}
	return (0);
}
