/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: esuso-es <esuso-es@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 17:11:32 by esuso-es          #+#    #+#             */
/*   Updated: 2022/07/13 10:31:36 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void 	ft_ultimate_div_mod(int *a, int *b)
{
	int	division;
	
	division = *a / *b;
	*b = *a % *b;
	*a = division;
}

int	main()
{
	int a;
	int	b;
	
	a = 20;
	b = 5;
	ft_ultimate_div_mod(&a,&b);
	printf("%d   %d", a, b);
	
		
}
