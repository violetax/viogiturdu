/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 12:34:29 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:24:52 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		b++;
	}
	return (b);
}

int main()
{
	char	*str = "hola";
	int		len = 0;

	len = ft_strlen(str);
	printf("%s → %d\n",str,len);
}
