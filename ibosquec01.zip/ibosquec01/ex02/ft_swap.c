/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 19:56:37 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:21:27 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}

int main() {
    int *a;
    int *b;

    int vala = 1;
    int valb = 2;

    a = &vala;
    b = &valb;

	printf("ANTES → %d %d\n",*a, *b);
    ft_swap(a,b);
	printf("DEPUES → %d %d\n",*a, *b);
}
