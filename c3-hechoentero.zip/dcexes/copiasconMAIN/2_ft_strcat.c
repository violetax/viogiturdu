#include <stdio.h>

char	*ft_strcat(char *dest, char *src)
{
	char			*rdest;
	unsigned int	i;

	rdest = dest;
	while (*dest)
		dest++;

	i = 0;
	while (src[i])
	{
		*dest++ = *src++;
	}
	return (rdest);
}

int main() 
{
    char src[100] = "amigo";
    char dest[100] = "hola";

    printf("dest %s\n", dest);
    printf("dest %s\n", ft_strcat(dest, src));
}
