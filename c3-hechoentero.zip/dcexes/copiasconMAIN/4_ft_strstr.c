#include <stdio.h>
 
char	*ft_strstr(char *str, char *to_find)
{
	while (*str != '\0')
	{
		if (*str == *to_find) 
		{
			return (to_find);
		}
		str++;
	}
	return ('\0');
}

int main() {
	char	*str;
	char	*to_find; 

	str = "habia una vez un circo";
	*to_find = 'v';
	printf("probando %c\n", *to_find);
	printf("to_find: %s\n", ft_strstr(str, to_find));
}
