#include <stdio.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	char			*rdest;
	unsigned int	i;

	rdest = dest;
	while (*dest)
		dest++;
	i = 0;
	while (src[0] != '\0' && i <= size - 1)
	{
		printf("i %d\n", i);
		*dest++ = *src++;
		i++;
	}
	dest[i] = '\0';
	return (i);
}

int main() 
{
    char src[100] = "amigo";
    char dest[100] = "hola";

    printf("dest %s\n", dest);
    printf("dest %d\n", ft_strlcat(dest, src, 4));
}
