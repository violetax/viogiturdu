#include <stdio.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char			*rdest;
	unsigned int	i;

	rdest = dest;
	while (*dest)
		dest++;

	i = 0;
	while (src[0] != '\0' && i <= nb)
	{
		*dest++ = *src++;
		i++;
	}
	return (rdest);
}

int main() 
{
    char src[100] = "amigo";
    char dest[100] = "hola";

    printf("dest %s\n", dest);
    printf("dest %s\n", ft_strncat(dest, src, 2));
}

