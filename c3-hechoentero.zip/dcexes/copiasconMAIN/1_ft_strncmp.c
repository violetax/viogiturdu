#include <stdio.h>
//int	ft_strcmp(char *s1, char *s2)
int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	char			*p;
	unsigned int	i;

	i = 0;
	while (s1[i] != '\0' && i <= n)
	{
		if (s1[i] > s2[i])
			return (1);
		else if (s1[i] < s2[i])
			return (-1);
		i++;
	}
	if (s1[i] == '\0' && s2[i] != '\0')
		return (-1);
	return (0);
}

int main(void)
{
	char			*s1;
	char			*s2;
	char			*s3;
	int				i;

	s1 = "uno dos y tres";
	s2 = "uno";
	s3 = "uno";
	
	i = ft_strncmp(s1, s2, 3);
	printf("'%s' pasa 3 '%s', retorna '1' → %d\n", s1, s2, i);
	i = ft_strncmp(s2, s1, 5);
	printf("'%s' pasa 5 '%s', retorna '-1' → %d\n", s2, s1, i);
	i = ft_strncmp(s3, s2, 5);
	printf("'%s' pasa 5 '%s', retorna '0' → %d\n", s2, s3, i);
	return (0);
}
