/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cprog.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <viogonza@student.42urduliz.fr>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 11:40:44 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/19 11:40:59 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	char			*rdest;
	unsigned int	i;

	rdest = dest;
	while (*dest)
		dest++;
	i = 0;
	while (src[0] != '\0' && i <= size - 1)
	{
		printf("i %d\n", i);
		*dest++ = *src++;
		i++;
	}
	dest[i] = '\0';
	return (i);
}
