/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <viogonza@student.42urduliz.fr>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 11:13:30 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/19 11:14:19 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char			*rdest;
	unsigned int	i;

	rdest = dest;
	while (*dest)
		dest++;

	i = 0;
	while (src[0] && i <= nb)
	{
		*dest++ = *src++;
		i++;
	}
	return (rdest);
}
