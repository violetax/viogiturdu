#!/bin/bash


source Asksure.fu
source Opte.fu
source Continua.fu
 

for cf in $(find ex* -name "*c")
do
    vim -c "set nonumber" ${cf} 
   continua
done  
