find . -type f -name "*.sh" | sed -ne "s/\.sh//p" | sed -ne "s?^.*/??p" 2>/dev/null
