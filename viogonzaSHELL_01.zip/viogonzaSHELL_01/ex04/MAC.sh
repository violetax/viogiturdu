/sbin/ifconfig | grep ether | sed -ne "s/[[:blank:]]*ether[[:blank:]]*//p" | tr -d " "
