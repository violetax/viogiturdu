/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 19:26:43 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 08:56:20 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
 

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] < '0') || (str[i] > '9'))
		{
			printf("%d\n",0);
			return (0);
		}
		i++;
	}
	printf("%d\n",1);
	return (1);
}

int main()
{
	char	strNO[100]="kjad098lkj43";
	char	strSI[100]="123456";

	ft_str_is_numeric(strNO);
	ft_str_is_numeric(strSI);

	return 0;
}
