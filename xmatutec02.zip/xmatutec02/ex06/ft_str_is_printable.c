/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 20:56:52 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 09:07:41 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] < ' ') || (str[i] > '~'))
			return (0);
		i++;
	}
	return (1);
}
int main()
{
    char    strSI[100]="AKADGAD";
    char    strNO[100]="ldfiæAGAAHkkasdij";

    int     i;
    i=0;

    i = ft_str_is_printable(strSI);
    printf("%d\n",i);
    i = ft_str_is_printable(strNO);
    printf("%d\n",i);
    return 0;
}
