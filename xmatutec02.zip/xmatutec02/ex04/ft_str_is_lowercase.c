/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 20:40:11 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 08:59:34 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>#include <stdio.h>
#include <stdio.h>#include <stdio.h>
#include <unistd.h>
 

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] < 'a') || (str[i] > 'z'))
		{
			printf("%d\n",0);
			return (0);
		}
		i++;
	}
	printf("%d\n",1);
	return (1);
}

int main()
{
	char	strSI[100]="ldfkkasdij";
	char	strNO[100]="ldfiAGAAHkkasdij";

	ft_str_is_lowercase(strSI);
	ft_str_is_lowercase(strNO);
	return 0;
}
