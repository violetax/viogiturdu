#!/bin/bash


source Asksure.fu
source Opte.fu
source Continua.fu
 

for f in $(find . -name "*c")
do
	clear
	echo -e "\033[38;5;190m" 
	ls ${f}  
	echo -e "\033[38;5;195m" 
#	sed -ne "/main/,/}/p" ${f}
	cat ${f}  
    continua
done

   	


