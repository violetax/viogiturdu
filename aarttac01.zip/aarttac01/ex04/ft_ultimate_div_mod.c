/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 17:15:25 by aarteta           #+#    #+#             */
/*   Updated: 2022/07/14 18:00:49 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	patxi;
	int	aitor;

patxi = *a / *b;
aitor = *a % *b;
*a = patxi;
*b = aitor;
}

int main(void)
{
	int a;
	int b;

	a = 20;
	b = 7;

	ft_ultimate_div_mod(&a, &b);
	printf("%d | %d", a, b);

	return(0);
}
