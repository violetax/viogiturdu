/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 18:57:36 by aarteta           #+#    #+#             */
/*   Updated: 2022/07/14 18:02:53 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>


int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

int main()
{
	char	*str = "hola";
	int		len = 0;

	len = ft_strlen(str);
	printf("%s → %d\n",str,len);
}
