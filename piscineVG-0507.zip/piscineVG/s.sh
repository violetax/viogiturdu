#!/bin/bash

source Continua.fu
 

#cexes=( "cexe.0" "cexe.1" "cexe.2" "cexe.3" "cexe.4" "cexe.5" "cexe.6" "cexe.7" "cexe.8" )
cexes=( "cexe.6" "cexe.7" "cexe.8" )
 

for ce in ${cexes[@]} 
do
	let d=${ce#cexe.}
	ddir="ex0${d}"  

	[[ ! -d ${ddir} ]] && mkdir ${ddir} 	
	vim ${ce} 
   continua
done   
		
