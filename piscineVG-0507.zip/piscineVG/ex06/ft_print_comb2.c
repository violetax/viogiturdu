/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/05 16:36:56 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/05 18:38:37 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c) {
	write(1,&c,1);
}

//void    print_end(char position_4, char position_3, char position_2, char position_1)
void    print_end(void)
{
    char comma = 44;
    char space = 32;

//    if (  )
//    {
        ft_putchar(comma);
        ft_putchar(space);
//	}
//	else
//	{
//		ft_putchar(position_1);
//		ft_putchar(position_2);
//		ft_putchar(position_3);
//		ft_putchar(position_4);
//	}
}

void    print_tetra(char position_4, char position_3, char position_2, char position_1)
{
	char space = 32;

    ft_putchar(position_4);
    ft_putchar(position_3);
	ft_putchar(space);
    ft_putchar(position_2);
	ft_putchar(position_1);
//    print_end(position_4,position_3,position_2,position_1);
	print_end();
}

void	ft_print_comb2(void)
{
	char number_one;
	char number_two;
	char number_three;
	char number_four;
	
	number_four = '0';
	number_three = '0';

			
	number_two = '0';
	while ( number_two <= '9' )
	{
		number_one = '0';
		while ( number_one <= '9' )
		{
			print_tetra(number_four,number_three,number_two,number_one);
			number_one++;
		}
		number_two++;
	}
}
