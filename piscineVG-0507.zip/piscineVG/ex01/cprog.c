#include <unistd.h>

void ft_putchar(char c) {
	write(1,&c,1);
}

void ft_print_alphabet(void) {
	char comienzo = 'a';
	char final = 'z';
	while ( comienzo <= final ) {
		ft_putchar(comienzo);
		comienzo = comienzo + 1;
	}
}

int main() {
	ft_print_alphabet();
}
