/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cprog.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/04 14:38:19 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/04 14:55:07 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putchar(char c) {
	write(1,&c,1);
}

void ft_is_negative(int n)
{
	if ( n <= 2147483647 && n > -2147483648 )
	{
		if ( n < 0 ) 
		{
			ft_putchar('N');
		}
		else
		{
			ft_putchar('P');
		}
	}
}
int main() {
	int entero = -3 ;
	while ( entero < 5 ) {
		ft_is_negative(entero);
		ft_putchar('\n');
		entero = entero + 1 ;
	}
}
