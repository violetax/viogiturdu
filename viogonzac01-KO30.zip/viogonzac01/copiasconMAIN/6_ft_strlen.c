/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 14:51:20 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:19:30 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_strlen(char *str)
{
	char	*p;
	int		len;

	len = 0;
	p = str;
	while (p[0] != '\0')
	{
		p++;
		len++;
	}
	return (len);
}
int main()
{
	char	*str = "hola";
	int		len = 0;

	len = ft_strlen(str);
	printf("%s → %d\n",str,len);
}
