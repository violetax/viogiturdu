/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 14:43:12 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 19:56:08 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
void	ft_div_mod(int a, int b, int *div, int *mod)
{
	float	quo;
	int		quoi;
	int		resti;

	quo = (float) a / (float) b;
	quoi = a / b;
	resti = (int)((quo - (float) quoi) * 1000000.0);
	while (resti % 10 == 0)
	{
		resti = resti / 10;
	}
	*div = (int) quoi;
	*mod = (int) resti;
}
int main() {

    int a = 85;
    int b = 4;
	int i, j;
    int *div;
    int *mod;

	i = 0;
	j = 0;
    div = &i;
    mod = &j;


    ft_div_mod(a,b,div,mod);
	printf("a y b → %d y %d\n",a,b);
	printf("DIV →  %d\n",*div);
	printf("MOD → %d\n",*mod);


return 0;
}
