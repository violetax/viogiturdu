/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 16:05:50 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:12:47 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
int main() {

    int basen = 83;
    int *onePtr = &basen;
    int **twoPtr = &onePtr;
    int ***threePtr = &twoPtr;
    int ****fourPtr = &threePtr;
    int *****fivePtr = &fourPtr;
    int ******sixPtr = &fivePtr;
    int *******sevenPtr = &sixPtr;
    int ********eightPtr = &sevenPtr;
    int *********nbr = &eightPtr;

    printf("*********nbr main →  %d\n",*********nbr); // 83
    ft_ultimate_ft(nbr);
    ft_ultimate_ft(nbr); // 42
    printf("*********nbr after func %d\n",*********nbr); // 42


    return 0;
}
