/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 16:10:37 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:11:27 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ft(int *nbr)
{
	int	fortytwo;

	fortytwo = 42;
	*nbr = fortytwo;
}
int main()
{
	int	i;
	int *nbr;
	
	i = 875;
	nbr = &i;
	ft_ft(nbr);
	printf("%d\n",i);
}
