/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 20:09:55 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:33:04 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
void	ft_ultimate_div_mod(int *a, int *b)
{
	int		aval;
	int		bval;
	float	quo;

	aval = *a;
	bval = *b;
	quo = (float) aval / (float) bval;
	aval = (float) aval / (float) bval;
	bval = (quo - aval) * 1000000.0;
	while (bval % 10 == 0)
	{
		bval = bval / 10;
	}
	*a = aval;
	*b = bval;
}
int main() {

    int *a;
    int *b;
	int i, j;

	i = 45;
	j = 38;

	a = &i;
	b = &j;

	printf("PRE ⇒  a y b → %d y %d\n",*a,*b);
    ft_ultimate_div_mod(a,b);

	printf("POST ⇒  a y b → %d y %d\n",*a,*b);


return 0;
}
