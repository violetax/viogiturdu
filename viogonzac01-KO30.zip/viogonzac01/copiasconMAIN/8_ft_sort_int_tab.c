/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 14:53:08 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:21:26 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

//void	ft_sort_int_tab(int *tab, int size)
int*	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	tmp;

	i = 0;
	while (++i < size)
	{
		if (tab[i] < tab[i - 1])
		{
			tmp = tab[i];
			tab[i] = tab[i - 1];
			tab[i - 1] = tmp;
			i = 0;
		}
	}
	return (tab);
}
int main() {

    int a[] = {100, 2, 56, 4, 10, 15, 1, 95, 2};
    int *b;
    int i = 0;
    int size = 9;

    b = ft_sort_int_tab(a, size);
    while (i < size)
    {
        printf("p\t→ %d\n",b[i]);
        i++;
    }

return 0;
}

