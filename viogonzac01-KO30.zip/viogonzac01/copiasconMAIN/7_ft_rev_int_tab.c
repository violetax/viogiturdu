/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 14:51:54 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:20:21 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int*	ft_rev_int_tab(int *tab, int size)
//void	ft_rev_int_tab(int *tab, int size)
{
	static int	p[] = {0};
	int			i;

	i = 0;
	size--;
	while (size >= 0)
	{
		p[i] = tab[size];
		i++;
		size--;
	}
	return (p);
}
int main() {

    int tab[] = {1, 2, 3, 4};
    int *p;
    int size;
    int i;

    p = tab;
    i = 0;
    size = 4;

    p = ft_rev_int_tab(tab, size);
    while (i < size)
    {
        printf("p\t→ %d\n",p[i]);
        i++;
    }
	i = 0;
	printf("----\n");
    while (i < size)
    {
        printf("tab\t→ %d\n",tab[i]);
        i++;
    }

return 0;
}
