/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 17:18:55 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:23:54 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar_nl(char c)
{
	char	newline;

	newline = 10;
	write(1, &c, 1);
	write(1, &newline, 1);
}

void	ft_putstr(char *str)
{
	char	*p;
	char	print;

	p = str;
	while (p[0] != '\0')
	{
		print = *p;
		ft_putchar_nl(print);
		p++;
	}
}
