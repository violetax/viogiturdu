/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 17:17:17 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/12 17:17:21 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int		aval;
	int		bval;
	float	quo;

	aval = *a;
	bval = *b;
	quo = (float) aval / (float) bval;
	aval = (float) aval / (float) bval;
	bval = (quo - aval) * 1000000.0;
	while (bval % 10 == 0)
	{
		bval = bval / 10;
	}
	*a = aval;
	*b = bval;
}
