git log | grep "commit " | head -5
