/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikferna <mikferna@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 21:56:50 by mikferna          #+#    #+#             */
/*   Updated: 2022/07/14 13:56:31 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_str_is_printable(char *str)
{
	unsigned int	i;

	i = 0;
	if (str[i] == '\0')
		return (1);
	while (str[i] != '\0')
	{
		if (str[i] >= ' ' && str[i] <= '~')
			i++;
		else
			return (0);
	}
	return (1);
}
int main()
{
    char    strSI[100]="AKADGAD";
    char    strNO[100]="ldfiæAGAAHkkasdij";

    int     i;
    i=0;

    i = ft_str_is_printable(strSI);
    printf("%d\n",i);
    i = ft_str_is_printable(strNO);
    printf("%d\n",i);
    return 0;
}
