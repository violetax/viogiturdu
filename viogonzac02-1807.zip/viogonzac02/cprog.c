#include <stdio.h>


int	ft_char_is_loweralpha(char islalpha)
{
	if (islalpha >= 'a' && islalpha <= 'z')
		return (0);
	return (1);
}

int	ft_char_is_upperalpha(char isualpha)
{
	if (isualpha >= 'A' && isualpha <= 'Z')
		return (0);
	return (1);
}

int	ft_char_is_numeric(char isnum)
{
	if (isnum >= 0 && isnum <= 9)
		return (0);
	return (1);
}

int	ft_char_is_not_alphanum(char nonan)
{
	unsigned int	notan;

	notan = ft_char_is_loweralpha(nonan);
	if (notan == 1)
	{
		notan = ft_char_is_upperalpha(nonan);
		if (notan == 1)
		{
			notan = ft_char_is_numeric(nonan);
			if (notan == 1)
				return (0);
		}
	}
	return (1);
}

char	*ft_strcapitalize(char *str)
{
	unsigned int	i;
	int				islalpha;
	int				nonan;

	i = 0;
	while (str[i])
	{
		islalpha = ft_char_is_loweralpha(str[i]);
		nonan = ft_char_is_not_alphanum(str[i]);
		if (i == 0 && islalpha == 0)
			str[i] -= 0x20;
		else if (nonan == 0)
		{
			if (ft_char_is_loweralpha(str[i] + 1) == 0)
				str[i] -= 0x20;
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char str0[100] = " uno DoleTRELE 09catole -word =IS *good";
	printf("%s\n", ft_strcapitalize(str0));
	return (0);
}
