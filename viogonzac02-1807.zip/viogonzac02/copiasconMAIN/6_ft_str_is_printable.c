#include <stdio.h>
 
int ft_str_is_printable(char *str)
{ 
	int	i;
    int	printable;


	i = 0;
    printable = 0;
    while (str[i] != '\0')
    {
        if ( str[i] >= 0x20 && str[i] <= 0x7F )
		{
            printable = 0;
		}
		else
		{
			return (1);
		}
		i++;
    }
    return (printable);
}

int	main(void)
{
	char	*strSI;
	char	*strNO;
	int		ret;
	
	strSI = "lkjsf, ldka(8457); fdjkg_jf";
	strNO = "ooooooooooooooooooooooooooooooo\x01\x05\x0a\x15";
	
	ret = ft_str_is_printable(strNO);
	printf("%s → %d\n", strNO, ret);

	ret = ft_str_is_printable(strSI);
	printf("%s → %d\n", strSI, ret);
	
	return (0);
}
