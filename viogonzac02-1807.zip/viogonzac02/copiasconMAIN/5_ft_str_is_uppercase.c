/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   5_ft_str_is_uppercase.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 16:55:41 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/18 18:44:02 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
 

int ft_str_is_uppercase(char *str)
{
    int             isupperc;
    int             range_min_hd;
    int             range_max_hd;
    unsigned int    i;

    isupperc = 0;
    range_min_hd = 0x41;
    range_max_hd = 0x5A;
    i = 0;
    while (str[i] != '\0')
    {
        isupperc = str[i];
        if (isupperc < range_min_hd || isupperc > range_max_hd)
        {
            return (0);
        }
        i++;
    }
    return (1);
}

int main ()
{
	char	*str1 = "DFLKGLADK";
	char	*str0 = ";lka-0";
	int		ret;

	ret = ft_str_is_uppercase(str1);
	printf("%s DEBE DE SER 1 → y es %d \n", str1, ret);
	ret = ft_str_is_uppercase(str0);
	printf("%s DEBE DE SER 0 → y es %d \n", str0, ret);
}
