#include <stdio.h>
#include <unistd.h>
 

unsigned int ft_strlcpy(char *dest, const char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0')
	{
		if (i < size)
			dest[i] = src[i];
		else if (i == size)
			dest[i] = '\0';
		i++;
	}

	return (i);
}

int	main()
{
	char	src[] = "habia una vez un circo";
	char	dest[100] = "que";
	unsigned int	i;
	unsigned int	size;

	size = 10;
	i = ft_strlcpy(dest,src,size);
	printf("Parametro size = %d\n", size);
	printf("Longtitud de strig src → %d\n", i);
	if (size < i)
		printf("%d is lower than %d → la copia esta truncada\n", size, i);
	else
		printf("%d is larger than %d → la copia es parcial\n", size, i);
}
