#include <stdio.h>
#include <unistd.h>

char	*ft_strupcase(char *str)
{
	unsigned int	i;
	
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 0x61 && str[i] <= 0x7A)
		{ 
			str[i] -= 32;
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char	str[] = "hola, como esta usted?";
	char	*upstr;

	upstr = ft_strupcase(str);
	printf("%s\n", upstr);

	return (0);
}
