/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 13:58:46 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/18 15:00:47 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
int main() {

	char src[100] = "evaluando";
	char dest[100] = "ft_strcpy";

	printf("dest antes → %s\n",dest);
	ft_strcpy(dest,src);
	printf("dest despues → %s\n",dest);

return 0;
}
