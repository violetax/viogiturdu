#include <stdio.h>

int	ft_char_is_loweralpha(char islalpha)
{
	if (islalpha >= 0x61 && islalpha <= 0x7A)
		return (0);
	return (1);
}

int ft_char_is_upperalpha(char isualpha)
{
	if (isualpha >= 0x41 && isualpha <= 0x5A)
		return (0);
	return (1);
}

int ft_char_is_numeric(char isnum)
{
	if (isnum >= 0x30 && isnum <= 0x7A)
		return (0);
	return (1);
}

int	ft_char_is_not_alphanum(char nonan)
{
	unsigned int	notan;
	notan = ft_char_is_loweralpha(nonan);
	if (notan == 1)
		notan = ft_char_is_upperalpha(nonan);
		if (notan == 1)
			notan = ft_char_is_numeric(nonan);
				if (notan == 1)
					return (0);
	return (1);
}

char	*ft_strcapitalize(char *str)
{
	unsigned int	i;
	int				islalpha;
	int				nonan;

	i = 0;
	while (str[i])
	{
		islalpha = ft_char_is_loweralpha(str[i]);
		nonan = ft_char_is_not_alphanum(str[i]);
		if (i == 0 && islalpha == 0)
			str[i] -= 0x20;
		else if (nonan == 0)
		{
			i++;
			if (ft_char_is_loweralpha(str[i]) == 0)
				str[i] -= 0x20;
		}
		i++;
	}
	return (str);
}

int	main()
{
//	char	str[]="esta es Una string, para:convertirse SI O SIonoi me cagoen l puta";
	char	str[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	char	*edited;

	edited = ft_strcapitalize(str);
	printf("%s\n", edited);
}
