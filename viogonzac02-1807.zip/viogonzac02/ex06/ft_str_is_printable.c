/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 21:13:23 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/18 21:15:28 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;
	int	printable;

	i = 0;
	printable = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 0x20 && str[i] <= 0x7F)
		{
			printable = 0;
		}
		else
		{
			return (1);
		}
		i++;
	}
	return (printable);
}
