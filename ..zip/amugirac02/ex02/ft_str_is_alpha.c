/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 19:16:08 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/07 08:35:13 by amugira-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	i;
	int	control;

	control = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			control = 1;
		}
		else if (str[i] >= 'A' && str[i] <= 'Z')
		{
			control = 1;
		}
		else
		{
			return (0);
		}
		i++;
	}
	return (control);
}
