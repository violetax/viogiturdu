/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex03.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 19:16:08 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/11 09:19:41 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;
	int	control;

	control = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			control = 1;
		}
		else
		{
			return (0);
		}
		i++;
	}
	return (control);
}

int main()
{
	char *str;

	str = "1234";
	printf("resultado: %d", ft_str_is_numeric(str));
	return 0;
}
