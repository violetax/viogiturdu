/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex07.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 10:18:56 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/11 09:34:42 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if(str[i] >= 'a' && str[i] <= 'z')
		{
			str[i] = str[i] - 32;
			i++;
		}
	}
	return (str);
}

int main()
{
    char str[] = "geeksforgeeks is the best";
    //converting the given string into uppercase.
//    printf("%s \n", strupr(str));
	str = &ft_strupcase(str);
    
	printf("%s \n", str);
    return  0;
}
//int main()
//{
//	char* str[4] = "hola";
//
//	printf("resultado: %s", ft_strupcase(str));
//	return 0;
//}
