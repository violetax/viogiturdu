/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex03.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 09:17:08 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/07 09:25:34 by amugira-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;
	int	control;

	control = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			control = 1;
		}
		else
		{
			return (0);
		}
		i++;
	}
	return (control);
}

int main()
{
	char *str;

	str = "holaaa";
	printf("resultado: %d", ft_str_is_lowercase(str));
	return 0;
}
