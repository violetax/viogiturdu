/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 16:07:23 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/11 09:16:41 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strcpy(char *dest, char *src)
{
	int i;

	i = 0;

	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int main() {
  char str1[20] = "C programming";
  char str2[20];

  // copying str1 to str2
  strcpy(str2, str1);
  puts(str2); // C programming

  ft_strcpy(str2, str1);
  puts(str2); // C programming

  return 0;
}

//int main() {
//
//	char str1[5];
//	char str2[5] = "adios";
//	
//	printf("resultado = %s", ft_strcpy(str1, str2));
//	printf("resultado = %s", strcpy(str1, str2));
//
//	return (0);	
//
//}
