/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 12:10:08 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/13 13:01:49 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	init;
	int	*start_side;
	int	*end_side;

	init = 0;
	start_side = &init;
	end_side = &init;
	i = 0;
	while (i < size / 2)
	{
		start_side = &tab[i];
		end_side = &tab[size - 1 - i];
		ft_swap(start_side, end_side);
		i++;
	}
}
