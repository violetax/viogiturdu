
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 11:02:56 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/13 11:03:27 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
 
void	ft_ultimate_div_mod(int *a, int *b)
{
	printf("a ANTES → %d \n",*a);
	printf("b ANTES → %d \n",*b);


    int aval;
    int bval;

    aval = *a;
    bval = *b;

    *a = aval / bval;
    *b = aval % bval;


	printf("a DESPUES → %d \n",*a);
	printf("b DESPUES → %d \n",*b);

}

int main ()
{
 int *a;
 int *b;

 int i = 500;
 int j = 100;

	a = &i;
	b = &j;

 ft_ultimate_div_mod(a,b);
}
