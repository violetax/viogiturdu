/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 11:34:35 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/13 15:30:53 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	char	*p;
	char	print;

	p = str;
	while (p[0] != '\0')
	{
		print = *p;
		ft_putchar(print);
		p++;
	}
}


int main() {

	char *str = "hola";
	ft_putstr(str);


return 0;
}
