/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/01 13:44:17 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/04 11:49:34 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_is_negative(int n)
{
	char	l;

	if (n < 0)
	{
		l = 'N';
	}
	else
	{
		l = 'P';
	}
	ft_putchar(l);
}
int main() {
	//int i = 42;
	ft_is_negative(42);
	ft_is_negative(-42);
	ft_is_negative('\0');
	ft_is_negative(0);
}
