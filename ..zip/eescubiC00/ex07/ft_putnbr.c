/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/03 17:12:59 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/03 17:26:10 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	final(int tam, long aux, int resto, int nb)
{
	int		i;
	char	l;

	i = 0;
	while (i < tam)
	{
		aux /= 10;
		resto = nb / aux;
		nb = nb - aux * resto;
		l = resto + 48;
		ft_putchar (l);
		i++;
	}
}

void	mostrarbr(int nb)
{
	int		resto;
	int		tam;
	int		i;
	long	aux;

	resto = nb;
	tam = 0;
	while (resto > 0)
	{
		resto = resto / 10;
		tam++;
	}
	i = 0;
	aux = 1;
	while (i < tam)
	{
		aux *= 10;
		i++;
	}
	final (tam, aux, resto, nb);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
	}
	else
	{
		if (nb < 0)
		{
			ft_putchar('-');
			nb = nb * -1;
		}
		else
		{
			if (nb == 0)
			{
				ft_putchar('0');
			}
		}
	}
	mostrarbr(nb);
}
