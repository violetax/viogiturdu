/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikferna <mikferna@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 15:19:11 by mikferna          #+#    #+#             */
/*   Updated: 2022/07/14 13:52:38 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
 
char	*ft_strcpy(char *dest, char *src)
{
	unsigned int	i;

	printf("pre src → %s\n",src);
	printf("pre dest → %s\n",dest);

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	printf("post src → %s\n", src);
	printf("post dest → %s\n", dest);
	return (dest);
}
int main()
{
	char	src[100] = "joder la ppl";
	char	dest[100] = "que brasas";

	ft_strcpy(dest,src);
	return 0;
}

