/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikferna <mikferna@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 21:40:14 by mikferna          #+#    #+#             */
/*   Updated: 2022/07/14 13:55:39 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_str_is_lowercase(char *str)
{
	unsigned int	i;

	i = 0;
	if (str[i] == '\0')
		return (1);
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			i++;
		else
				printf("%d\n",0);
			return (0);
	}
	printf("%d\n",1);
	return (1);
}
int main()
{
	char	strSI[100]="ldfkkasdij";
	char	strNO[100]="ldfiAGAAHkkasdij";

	ft_str_is_lowercase(strSI);
	ft_str_is_lowercase(strNO);
	return 0;
}
