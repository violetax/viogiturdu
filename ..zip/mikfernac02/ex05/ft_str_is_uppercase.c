/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mikferna <mikferna@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 21:46:02 by mikferna          #+#    #+#             */
/*   Updated: 2022/07/14 13:56:10 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	unsigned int	i;

	i = 0;
	if (str[i] == '\0')
		return (1);
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			i++;
		else
			return (0);
	}
	return (1);
}
int main()
{
    char    strSI[100]="AKADGAD";
    char    strNO[100]="ldfiAGAAHkkasdij";
	int		i;
	i=0;

    i = ft_str_is_uppercase(strSI);
	printf("%d\n",i);
    i = ft_str_is_uppercase(strNO);
	printf("%d\n",i);
    return 0;
}
