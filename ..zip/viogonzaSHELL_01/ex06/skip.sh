ls -l | awk '{l=!l; if ( l ) print }'
