sed -ne "${FT_LINE1},${FT_LINE2}p" /etc/passwd | grep -v "^#" | cut -d: -f1 | rev | sort -r | awk -v ORS=',' '{l=!l; if ( l ) print }' | sed -ne "s/,/, /gp" | sed -ne "s/, $/\./p" | tr -d '\n'
