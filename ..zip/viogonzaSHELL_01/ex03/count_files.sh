find . -type f -o -type d | awk '{n++}END{print n}'
