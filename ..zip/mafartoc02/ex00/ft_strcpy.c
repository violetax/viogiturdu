/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mafarto- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 11:03:45 by mafarto-          #+#    #+#             */
/*   Updated: 2022/07/13 08:44:20 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
 
char	*ft_strcpy(char *dest, char *src)
{
	int	x;

	x = 0;
	while (src[x] != '\0')
	{
		dest[x] = src[x];
		x ++;
	}
	dest[x] = '\0';
	return (dest);
}
 int main ()
{
	char src[100] = "evaluando";
	char dest[100] = "no";

 ft_strcpy(dest,src);
 printf("%s\n",dest);
}
