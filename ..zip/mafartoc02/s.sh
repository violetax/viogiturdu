#!/bin/bash


source Asksure.fu
source Opte.fu
source Continua.fu

let i=0

for mff in $(find . -name "*c")
do
	name=$(basename ${mff}) 
	cp ${mff} ft_${i}_${name#ft_} 
	let i=${i}+1 
done	



