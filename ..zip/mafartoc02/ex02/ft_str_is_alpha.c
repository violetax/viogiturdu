/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mafarto- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 11:58:13 by mafarto-          #+#    #+#             */
/*   Updated: 2022/07/13 08:55:19 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
 

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 'A' || (str[i] > 'Z' && str[i] < 'a') || str[i] > 'z')
			return (0);
		i++;
	}
	return (1);
}

int main ()
{
	char	*str0 = "ka;'fkg[0;kl/*";
	char	*str1 = "alkjfsldjfDFAKL";
	char	*str2 = "";
	int	ret;

	ret = ft_str_is_alpha(str0);

	printf("%s\n",str0);
	printf("%d\n",ret);

	ret = ft_str_is_alpha(str1);
	   
	printf("%s\n",str1);
	printf("%d\n",ret);

	ret = ft_str_is_alpha(str2);

	printf("%s\n",str2);
	printf("%d\n",ret);


}
