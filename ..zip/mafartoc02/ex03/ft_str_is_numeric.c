/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mafarto- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/08 14:30:02 by mafarto-          #+#    #+#             */
/*   Updated: 2022/07/13 09:09:29 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
 

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < '0' || str[i] > '9')
			return (0);
		i++;
	}
	return (1);
}

int main ()
{
	char	*strdigits = "1654648410";
	char	*strother = "57df8ss";
	int		ret;

	ret = ft_str_is_numeric(strdigits);
	printf("%s\n",strdigits);
	printf("%d\n",ret);

	ret = ft_str_is_numeric(strother);
	printf("%s\n",strother);
	printf("%d\n",ret);

	
}
