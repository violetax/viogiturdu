/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 13:08:34 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 09:20:02 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_strlen(char *str)
{
	int		i;
	char	c;

	i = 0;
	c = str[0];
	while (c != 0)
	{
		i++;
		c = str[i];
	}
	return (i);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int c)
{
	unsigned int	i;
	unsigned int	r;
	printf("%s\n",dest);

	r = ft_strlen(src);
	i = 0;
	while ((src[i] != 0) && (i < c - 1))
	{
		dest[i] = src[i];
		i++;
	}
	while (i < c)
	{
		dest[i] = 0;
		i++;
	}
	printf("%s\n",dest);
	printf("%d\n",r);
	return (r);
}
int main()
{
	char    src[100]="AKADGAD";
    char    dest[100]="ldfiAGAAHkkasdij";
	unsigned int	size;
	size=3;

	ft_strlcpy(dest, src, size);
	return 0;
}

