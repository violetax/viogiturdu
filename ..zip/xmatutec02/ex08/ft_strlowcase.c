/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 11:47:10 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 09:11:53 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strlowcase(char *str)
{
	int		i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] >= 'A') && (str[i] <= 'Z'))
			str[i] = str[i] + 32;
		i++;
	}
	printf("%s\n",str);
	return (str);
}
int main()
{
    char    strSI[100]="GADFG";
//    char    strNO[100]="ldfiAGAAHkkasdij";

	ft_strlowcase(strSI);
//    ft_str_is_lowercase(strNO);
    return 0;
}
