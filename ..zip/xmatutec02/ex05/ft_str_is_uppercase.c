/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 20:49:05 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 09:05:27 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] < 'A') || (str[i] > 'Z'))
			return (0);
		i++;
	}
	return (1);
}
int main()
{
    char    strSI[100]="AKADGAD";
    char    strNO[100]="ldfiAGAAHkkasdij";
	int		i;
	i=0;

    i = ft_str_is_uppercase(strSI);
	printf("%d\n",i);
    i = ft_str_is_uppercase(strNO);
	printf("%d\n",i);
    return 0;
}
