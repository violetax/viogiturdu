/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xmatute- <xmatute-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 21:44:18 by xmatute-          #+#    #+#             */
/*   Updated: 2022/07/14 09:10:05 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
char	*ft_strupcase(char *str)
{
	int		i;

	i = 0;
	while (str[i] != 0)
	{
		if ((str[i] >= 'a') && (str[i] <= 'z'))
			str[i] = str[i] - 32;
		i++;
	}
	printf("%s\n",str);
	return (str);
}
int main()
{
    char    strSI[100]="lsdskajfal";
//    char    strNO[100]="ldfiAGAAHkkasdij";

	ft_strupcase(strSI);
//    ft_str_is_lowercase(strNO);
    return 0;
}
