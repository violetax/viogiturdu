#!/bin/bash


source Asksure.fu
source Opte.fu
source Continua.fu
 
for repo in $(find . -maxdepth 1 -type d)
do
	rm -f ${repo}/.git
    ziprepo=${repo}.zip	
	zip -r ${ziprepo} ${repo}
	mv ${ziprepo} /Users/viogonza/viogiturdu
done	

exit
for f in $(find . -name "*c")
do
	clear
	echo -e "\033[38;5;190m" 
	ls ${f}  
	echo -e "\033[38;5;195m" 
#	sed -ne "/main/,/}/p" ${f}
	cat ${f}  
    continua
done

   	


