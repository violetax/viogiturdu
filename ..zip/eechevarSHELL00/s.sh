#!/bin/bash


for d in $(find . -type d -name "[^\.]*[^\.]*")
do
	echo "Directorio $d: " 
	ls -l $d
	cat $d/*
	echo "--"
done
