#include <stdio.h>


int	ft_atoi(char *str)
{
	int	num;
	int	sign;
	int	i;

	num = 0;
	sign = 0;
	i = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v' || str[i] ==  '\f' || str[i] == '\r' || str[i] == ' ')
	{
		i++;
	}
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign++;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = (num * 10) + (str[i] - '0');
		i++;
	}
	if (sign % 2 == 1)
		num = num * -1;
	return (num);
}

int	main(void)
{
	char *num = "	  ---+--+1234ab567";

	printf("atoi →  %d\n", ft_atoi(num));
	return (0);
}
