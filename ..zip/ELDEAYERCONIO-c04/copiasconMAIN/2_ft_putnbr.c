/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/20 23:29:19 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/21 00:37:06 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
 

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	char	sign;

	sign = '-';
	if (nb < 0)
	{
		write(1, &sign, 1);
		nb *= -1;
	}
	if (nb == -2147483648)
	{
		write(1, "2147483648", 10);
		return;
	}
	if (nb > 9)
		ft_putnbr(nb / 10);
	ft_putchar(nb % 10 + '0');
}

int	main(void)
{
	int	num1 = -2147483648;
	int	num2 = -87516;
	int	num3 = 8941;

	ft_putnbr(num1);
	printf("\n");
	ft_putnbr(num2);
	printf("\n");
	ft_putnbr(num3);
	printf("\n");
	return (0);
}
