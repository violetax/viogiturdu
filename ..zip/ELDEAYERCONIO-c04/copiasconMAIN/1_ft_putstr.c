/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/20 23:36:49 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/20 23:40:07 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
 
void	ft_putstr(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}	

int main(void)
{
	char	str[] = "verano 2022";

	ft_putstr(str);
	return (0);
}
