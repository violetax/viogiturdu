/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 10:27:33 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/15 13:44:40 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_is_prime(int nb);

int	ft_find_next_prime(int nb)
{
	int	i;

	i = nb;
	while (i < 2147483647)
	{
		if (ft_is_prime(i))
			return (i);
		i++;
	}
	return (0);
}

int	ft_is_prime(int nb)
{
	int	i;
	int	cont;

	if (nb <= 1)
		return (0);
	i = 2;
	cont = 1;
	while (i <= nb / 2 && cont)
	{
		if (nb % i == 0)
			cont = 0;
		i++;
	}
	return (cont);
}

int	main(void)
{
	int	i;

	for (i = 1000000111; i < 2000000000; i += 20)
	{
		printf("El siguiente primo de %d es %d\n", i, ft_find_next_prime(i));
	}
	return (0);
}
