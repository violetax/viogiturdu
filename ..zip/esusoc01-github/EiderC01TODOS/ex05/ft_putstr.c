/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: esuso-es <esuso-es@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 17:27:10 by esuso-es          #+#    #+#             */
/*   Updated: 2022/07/13 10:34:19 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
//int	ft_putstr(char *str)
//{
//	int	i;
//	i = 0;
//	while(str[i] != '\0')
//	{
//		write(1, &str[i], 1);
//		i++;
//	}
//	return (i);
//}
//El bueno
void	ft_putstr(char *str)
{
	int	i;
	i = 0;
	while(str[i] != '\0')
	{
		write(1, &str[i], 1);
		i++;
	}
	printf("El tamaño deñ array es: %d", i);
}

int	main()
{
//	int		size;
	char	*cadena;
	cadena = "Hola que ´lm,-lmlkjnlkjmtal";
	ft_putstr(cadena);
}

