/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: esuso-es <esuso-es@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 16:46:38 by esuso-es          #+#    #+#             */
/*   Updated: 2022/07/13 10:36:54 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int    ft_strlen(char *str)
{
    int i;
	i = 0;
    while(str[i] != '\0')
    {
        i++;
    }
    return(i);
}

int main()
{
    char    *str;
    str = "Hola";
    printf("%d", ft_strlen(str));
    return (0);
}
