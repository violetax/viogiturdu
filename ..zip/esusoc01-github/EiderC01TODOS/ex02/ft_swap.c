/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: esuso-es <esuso-es@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 12:02:24 by esuso-es          #+#    #+#             */
/*   Updated: 2022/07/13 10:30:36 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	aux;
	
	aux = *a;
	*a = *b;
	*b = aux;
}

int	main(void)
{
	 int 	a;
	 int 	b;
	 a = 7;
	 b = 77;
	 
	ft_swap(&a, &b);
	printf("%d  %d", a,b);
	return (0);
}
