/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 21:11:53 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/20 20:12:39 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdio.h>
int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int main(void)
{
    char    *strminu;
    char    *strother;
    int     ret;

    strminu = "lkadslf";
    strother = "iHHHHHhhhh";
    ret = ft_str_is_lowercase(strminu);
    printf("%s\n", strminu);
    printf("%d\n", ret);
    ret = ft_str_is_lowercase(strother);
    printf("%s\n", strother);
    printf("%d\n", ret);
}
