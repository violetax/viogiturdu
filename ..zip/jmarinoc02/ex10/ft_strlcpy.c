/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 17:23:25 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/19 22:11:09 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlen(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	x;

	i = 0;
	x = ft_strlen(src);
	if (size != 0)
	{
		if (size - 1 > ft_strlen(dest))
		{
			return (0);
		}
		while (src[i] != '\0' && i < (size -1))
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
	return (x);
}

int main()
{
    char    src[] = "habia una vez un circo";
    char    dest[100] = "que";
    unsigned int    i;
    unsigned int    size;

    size = 10;
    i = ft_strlcpy(dest,src,size);
    printf("Parametro size = %d\n", size);
    printf("Longtitud de strig src → %d\n", i);
    if (size < i)
        printf("%d is lower than %d → la copia esta truncada\n", size, i);
    else
        printf("%d is larger than %d → la copia es parcial\n", size, i);
}
