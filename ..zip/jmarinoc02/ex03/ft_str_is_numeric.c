/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 21:00:26 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/20 20:12:06 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int main(void)
{
    char    *strdigits = "1654648410";
    char    *strother = "57df8ss";
    int     ret;


    ret = ft_str_is_numeric(strdigits);
    printf("%s\n",strdigits);
    printf("%d\n",ret);

    ret = ft_str_is_numeric(strother);
    printf("%s\n",strother);
    printf("%d\n",ret);
    return (0);
}
