/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 01:46:26 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/20 20:11:36 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))
		{
			i++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}

int main(void)
{
    char    *str0;
    char    *str1;
    char    *strNULL;
    int     ret;

    str0 = "ka;'fkg[0;kl/*";
    str1 = "alkjfsldjfDFAKL";
    strNULL = "\0";
    ret = ft_str_is_alpha(str0);
    printf("%s\n", str0);
    printf("DEBE SER 0 → %d\n", ret);
    ret = ft_str_is_alpha(str1);
    printf("%s\n", str1);
    printf("DEBE SER 1 → %d\n", ret);
    ret = ft_str_is_alpha(strNULL);
    printf("(null string, empty outside partenthesis) %s\n", strNULL);
    printf("DEBE SER 1 → %d\n", ret);
}
