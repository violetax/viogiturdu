/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmarino- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 18:30:50 by jmarino-          #+#    #+#             */
/*   Updated: 2022/07/19 22:15:36 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
void	ft_putstr_non_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= ' ' && str[i] <= '~'))
		{
			str[i] = ('\\');
			i++;
		}
	}
//	printf("%s",str);
}

int main()
{
    char    src[] = "habia una vez\n un circo";
	int i;
	i++;

	printf("%s", ft_putstr_non_printable(src));
	return (0);
}

