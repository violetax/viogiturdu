/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jperez <jperez@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 19:43:08 by jperez            #+#    #+#             */
/*   Updated: 2022/07/12 13:18:32 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	check_entry(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (1);
			j++;
		}
		if (base[i] == '+' || base[j] == '-')
			return (1);
		if ('a' < base[i] && base[i] < 'a')
			base[i] = base[i] - ('a' - 'A');
		i++;
	}
	if (i < 2)
		return (1);
	return (0);
}

int	ft_recursive_power(int nb, int power)
{	
	if (power == 0)
		return (1);
	if (power > 1)
		nb = nb * ft_recursive_power(nb, power - 1);
	return (nb);
}

int	num_position(char *str, int pos)
{
	char	*hex;
	int		i;

	hex = "0123456789ABCDEF";
	i = 0;
	while (hex[i])
	{
		if (str[pos] == hex[i])
			return (i);
		i++;
	}
	return (0);
}

int	ft_atoi_base(char *str, char *base)
{
	int	num;
	int	i;
	int	j;
	int	l;

	if (check_entry(base) == 1)
		return (1);
	i = 0;
	while (base[i])
		i++;
	j = 0;
	while (str[j])
		j++;
	j--;
	num = 0;
	l = 0;
	while (j >= 0)
	{
		num = num + num_position(str, j) * ft_recursive_power(i, l);
		j--;
		l++;
	}
	return (num);
}

int	main(void)
{
	char	str[] = "1000";
	int		num;
//	num = ft_atoi_base(str, "0123456789");
	num = ft_atoi_base(str, "01");
	printf("%d", num);
	return (0);
}
