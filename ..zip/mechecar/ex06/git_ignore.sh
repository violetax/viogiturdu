git status | sed -n '/Untracked files:/,/no changes added/p' | grep -i -v -E '<file>|changes'
