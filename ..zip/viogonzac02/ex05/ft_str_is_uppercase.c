/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 17:39:55 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/19 21:08:25 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int				isupperc;
	int				range_min_hd;
	int				range_max_hd;
	unsigned int	i;

	isupperc = 0;
	range_min_hd = 0x41;
	range_max_hd = 0x5A;
	i = 0;
	while (str[i] != '\0')
	{
		isupperc = str[i];
		if (isupperc < range_min_hd || isupperc > range_max_hd)
		{
			return (0);
		}
		i++;
	}
	return (1);
}
