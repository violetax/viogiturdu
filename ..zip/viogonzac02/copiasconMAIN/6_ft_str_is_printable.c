#include <stdio.h>
#include <unistd.h>



int ft_str_is_printable(char *str)
{
    int c;

    c = 0;
    while (str[c] != '\0')
    {
        if ((str[c] < 32) || (str[c] > 126))
            return (0);
        c++;
    }
    return (1);
}

int	main(void)
{
	char	*strNO = "\x01\x05\x0a\x15";
	char	*strSI = "lkjsf, ldka(8457); fdjkg_jf";
	int		ret;

	ret = ft_str_is_printable(strNO);
	printf("%s → %d\n", strNO, ret);

	ret = ft_str_is_printable(strSI);
	printf("%s → %d\n", strSI, ret);
	return (0);
}
