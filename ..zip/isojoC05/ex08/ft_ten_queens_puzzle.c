/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_ueens_puzzle.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 10:46:18 by isojo-go          #+#    #+#             */
/*   Updated: 2022/07/11 11:18:48 by isojo-go         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int n)
{
	char	c;

	c = n - '0';
	write(1, &c, 1);
}

void	ft_nl(void)
{
	write(1, " \n", 2);
}

int	ft_ten_queens_puzzle(void)
{
	int	j;
	int	i;

	i = -1;
	while (++i <= 9)
	{
		j = 0;
		ft_putnbr(i, j);
		ft_nl();
	}
}
