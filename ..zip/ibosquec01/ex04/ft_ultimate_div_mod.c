/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 16:05:01 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:23:45 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	c;


	c = *a / *b;
	*b = *a % *b;
	*a = c;
}


int main(void)
{
	int a;
	int b;

	a = 20;
	b = 7;

	ft_ultimate_div_mod(&a, &b);
	printf("%d | %d", a, b);

	return(0);
}
