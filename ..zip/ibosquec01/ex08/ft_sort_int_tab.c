/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <ibosque-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 19:30:24 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:26:55 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	aux;
	int	i;

	i = 0;
	while (i < size - 1)
	{
		if (tab[i] > tab[i + 1])
		{
			aux = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = aux;
			i = 0;
		}
		else
		{
			i++;
		}
	}
}

int main() {

    int a[] = {100, 2, 56, 4, 10, 15, 1, 95, 2};
//    int *b;
    int i = 0;
    int size = 9;

//	b = a;

	printf("ORIGINAL\t\n");
    while (i < size)
    {
        printf("\t%d\n",a[i]);
        i++;
    }
    
	ft_sort_int_tab(a, size);

	printf("%s\n","-----------------------");

	printf("ORDENADO\t\n");
	i = 0;
    while (i < size)
    {
        printf("\t%d\n",a[i]);
        i++;
    }


return 0;
}
