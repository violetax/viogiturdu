/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 18:58:26 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:20:33 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <unistd.h>
 

void	ft_ultimate_ft(int *********nbr)

{
	*********nbr = 42;
}

int main() {

    int basen = 83;
    int *onePtr = &basen;
    int **twoPtr = &onePtr;
    int ***threePtr = &twoPtr;
    int ****fourPtr = &threePtr;
    int *****fivePtr = &fourPtr;
    int ******sixPtr = &fivePtr;
    int *******sevenPtr = &sixPtr;
    int ********eightPtr = &sevenPtr;
    int *********nbr = &eightPtr;

    printf("*********nbr main →  %d\n",*********nbr); // 83
    ft_ultimate_ft(nbr);
    ft_ultimate_ft(nbr); // 42
    printf("*********nbr after func %d\n",*********nbr); // 42


    return 0;
}
