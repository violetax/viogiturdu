/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ibosque- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 15:34:46 by ibosque-          #+#    #+#             */
/*   Updated: 2022/07/15 14:25:13 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
void	ft_rev_int_tab(int *tab, int size)
{
	int	aux;
	int	i;

	i = 0;
	while ((size / 2) > i)
	{
		aux = tab[i];
		tab[i] = tab[size - 1 - i];
		tab[size - 1 - i] = aux;
		i++;
	}
}
int main() {

    int tab[] = {1, 2, 3, 4};
    int *p;
    int size;
    int i;

    p = tab;
    size = 4;

    i = 0;
    while (i < size)
    {
        printf("ORIGINAL \t→ %d\n",p[i]);
        i++;
    }
    ft_rev_int_tab(tab, size);

	printf("----\n");

	i = 0;
    while (i < size)
    {
        printf("INVERTIDO\t→ %d\n",tab[i]);
        i++;
    }
return 0;
}
