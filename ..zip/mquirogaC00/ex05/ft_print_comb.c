/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mquiroga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/30 15:24:31 by mquiroga          #+#    #+#             */
/*   Updated: 2022/07/02 10:43:23 by mquiroga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_putchar(char c, char c2, char c3);

void	ft_print_comb(void)
{
	char	n1;
	char	n2;
	char	n3;

	n1 = '0' - 1;
	while (++n1 <= '7')
	{
		n2 = n1;
		while (++n2 <= '8')
		{
			n3 = n2;
			while (++n3 <= '9')
			{
				ft_putchar(n1, n2, n3);
			}
		}
	}
}

void	ft_putchar(char c1, char c2, char c3)
{
	if (c1 != c2 && c2 != c3 && c3 != c1)
	{
		write(1, &c1, 1);
		write(1, &c2, 1);
		write(1, &c3, 1);
		if (!(c1 == '7' && c2 == '8' && c3 == '9'))
		{
			write(1, ", ", 2);
		}
	}
}
