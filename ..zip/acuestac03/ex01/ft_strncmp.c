/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acuesta- <acuesta-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 13:32:56 by acuesta-          #+#    #+#             */
/*   Updated: 2022/07/19 18:06:21 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	c;

	c = 0;
	if (n == 0)
		return (n);
	while (s1[c] && s2[c] && s1[c] == s2[c] && n > c)
		c++;
	return (s1[c] - s2[c]);
}

int main()
{
    unsigned int n;
    char    s1[] = "holA q lo q?";
    char s2[] = "hola que lo qeu?";

    n = 5;
    ft_strncmp(s1, s2, n);
    printf("%d", ft_strncmp(s1, s2, n));
    return 0;
}
