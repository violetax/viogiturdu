/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acuesta- <acuesta-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 18:02:30 by acuesta-          #+#    #+#             */
/*   Updated: 2022/07/19 18:07:08 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcat(char *dest, char *src)
{
	int	c;
	int	i;

	c = 0;
	i = 0;
	while (dest[c])
	{
		c++;
	}
	while (src[i])
	{	
		dest[i + c] = src[i];
		i++;
	}
	dest[c + i] = '\0';
	return (dest);
}

int main()
{
    char dest[100] = "ihhhhhhhhhhhhhhhhhhhhhhhhhhh";
    char src[] = "q lo q da igual ";


    printf("%s", ft_strcat(dest, src));
    return 0;
}
