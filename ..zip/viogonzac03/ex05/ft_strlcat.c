/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/20 16:20:36 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/20 16:23:38 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	char			*rdest;
	unsigned int	i;
	unsigned int	j;

	rdest = dest;
	j = 0;
	while (*dest)
	{
		dest++;
		j++;
	}
	i = 0;
	while (src[i] != '\0' && i <= size - 1)
	{
		*dest++ = *src++;
		i++;
		j++;
	}
	dest[j] = '\0';
	i = getarlength(rdest) + 1;
	return (i);
}
