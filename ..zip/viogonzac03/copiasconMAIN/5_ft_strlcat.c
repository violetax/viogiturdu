#include <stdio.h>

int	getarlength(char *arr)
{
    unsigned int    len;

    len = 0;
    while (arr[len] != '\0')
        len++;
    return (len + 1);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
    char            *rdest;
    unsigned int    i;
    unsigned int    j;

    rdest = dest;
    j = 0;
    while (*dest)
    {
        dest++;
        j++;
    }
    i = 0;
    while (src[i] != '\0' && i <= size - 1)
    {
        *dest++ = *src++;
        i++;
        j++;
    }
    dest[j] = '\0';
    i = getarlength(rdest) + 1;
    return (i);
}

int	main(void)
{
    char src[100] = "amigo";
    char dest[100] = "hola!!!";

    printf("dest %s\n", dest);
    printf("dest %d\n", ft_strlcat(dest, src, 4));
	return (0);
}
