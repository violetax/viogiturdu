#!/bin/bash
groups=$(id $FT_USER -Gn)
echo ${groups// /,}
