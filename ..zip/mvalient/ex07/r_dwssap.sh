#!/bin/bash
cat /etc/passwd | sed '/^#/d' | sed -n 'n;p' | cut -d ":" -f1 | rev | sort -r | awk -v ft_1="$FT_LINE1" -v ft_2="$FT_LINE2" 'NR>=ft_1 && NR<=ft_2'| paste -sd ',' - | awk 'END{print $0 "."}'
