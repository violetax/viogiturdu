/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 16:59:39 by aarteta           #+#    #+#             */
/*   Updated: 2022/07/14 18:03:39 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	aux;

	aux = *a;
	*a = *b;
	*b = aux;
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;

	i = 0;
	while (i < size / 2)
	{
		ft_swap(&tab[i], &tab[size - 1 - i]);
		i++;
	}
}

int main() {

    int tab[] = {1, 2, 3, 4};
    int *p;
    int size;
    int i;

    p = tab;
    size = 4;

    i = 0;
    while (i < size)
    {
        printf("ORIGINAL \t→ %d\n",p[i]);
        i++;
    }
    ft_rev_int_tab(tab, size);

	printf("----\n");

	i = 0;
    while (i < size)
    {
        printf("INVERTIDO\t→ %d\n",tab[i]);
        i++;
    }
return 0;
}
