/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 17:06:30 by aarteta           #+#    #+#             */
/*   Updated: 2022/07/14 17:59:10 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	aux;

aux = *a;
*a = *b;
*b = aux;
}

int main() {
    int *a;
    int *b;

    int vala = 1;
    int valb = 2;

    a = &vala;
    b = &valb;

	printf("ANTES → %d %d\n",*a, *b);
    ft_swap(a,b);
	printf("DEPUES → %d %d\n",*a, *b);
}
