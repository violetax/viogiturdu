/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/12 17:11:16 by aarteta           #+#    #+#             */
/*   Updated: 2022/07/14 18:00:08 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
		printf("a → %d \n",a);
	printf("b → %d \n",b);
*div = a / b;
*mod = a % b;

	printf("div → %d \n",*div);
	printf("mod → %d \n",*mod);
}

int main ()
{
 int a = 25;
 int b= 14;

 int i = 0;
 int j = 0;
 int *div = &i;
 int *mod = &j;

 ft_div_mod(a,b,div,mod);
}
