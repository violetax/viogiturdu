int	ft_strlen(char *str)
{
	unsigned int	i;
	
	i = 0;
	while (str[i])
		i++;
	return (i);
}
