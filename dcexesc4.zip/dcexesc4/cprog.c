#include <stdio.h>
#include <unistd.h>

// isspace → space, form-feed ('\f'), newline ('\n'), carriage  return ('\r'), horizontal tab ('\t'), and vertical tab ('\v')
// ' '   (0x20)	space (SPC)
//'\t'	(0x09)	horizontal tab (TAB)
//'\n'	(0x0a)	newline (LF)
//'\v'	(0x0b)	vertical tab (VT)
//'\f'	(0x0c)	feed (FF)
//'\r'	(0x0d)	carriage return (CR)

int	ft_atoi(char *str)
{


int main(void)
{
	

	return (0);
}
