/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/11 07:29:04 by isojo-go          #+#    #+#             */
/*   Updated: 2022/07/11 07:39:28 by isojo-go         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	fact;

	fact = nb - 1;
	if (nb <= 1)
		return (0);
	else if (fact > 1)
		fact = fact * ft_recursive_factorial(fact);
	return (fact);
}
