/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex06.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 09:44:01 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/11 09:23:31 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;
	int	control;

	control = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= '!' && str[i] <= '~')
		{
			control = 1;
		}
		else
		{
			return (0);
		}
		i++;
	}
	return (control);
}

int main()
{
	char *str;
	char *str1;

	str = "jisbviawbvub!ascasc~asdevwebv1223467";
	str1 = "è〉";
	printf("resultado: %d", ft_str_is_printable(str));
	printf("resultado: %d", ft_str_is_printable(str1));
	return 0;
}
