/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prueba.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amugira- <amugira-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 17:58:02 by amugira-          #+#    #+#             */
/*   Updated: 2022/07/11 09:17:24 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

int main(void) 
{
	char dest[10];
	char *src = "holaaaa";

	printf("%s", ft_strncpy(dest ,src, 3));
	printf("%s", strncpy(dest, src, 3));

	return 0;
}

/* char* my_strncpy(char* dest, const char* src, unsigned int n)
{

    char* start = dest;
    while (*src && n--)
    {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0';
    return start;
}*/
