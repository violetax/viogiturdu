/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 15:03:09 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/15 15:11:12 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < 41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}

char	*ft_strlowcase(char *str)
{
	unsigned int	i;
	int				isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = ft_str_is_alpha(&str[i]);
		if (isalpha == 1 && str[i] >= 41 && str[i] <= 0x5A)
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char	str[] = "hola QUETAL ESTAS AQUI DENTRO de este SITIO";
	printf("%s\n", ft_strlowcase(str));
	return (0);
}
