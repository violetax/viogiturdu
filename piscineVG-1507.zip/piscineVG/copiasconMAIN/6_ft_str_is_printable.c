#include <stdio.h>
 
int ft_str_is_printable(char *str)
{ 
    unsigned char   c;
    char            *p;

    p = str;
    while (p[0] != '\0')
    {
		c = *p;
        if ( c >= 0x20 && c <= 0x7e )
            return 1;
        return 0;
    }
    return (1);
}

int	main(void)
{
	char	*strSI;
	char	*strNO;
	int		ret;
	
	strSI = "lkjsf, ldka(8457); fdjkg_jf";
	strNO = "ㄩ ㄩれゆ";
	ret = ft_str_is_printable(strNO);
	printf("%s → %d\n", strNO, ret);
	ret = ft_str_is_printable(strSI);
	printf("%s → %d\n", strSI, ret);
	ret = ft_str_is_printable(strNO);
	
	return (0);
}
