#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
//	isalpha = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
//		printf("str[%d] → %c → %c\n", i, str[i], isalpha);
		if (isalpha < 41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}

int	main(void)
{
	char	*str0;
	char	*str1;
	char	*strNULL;
	int		ret;

	str0 = "ka;'fkg[0;kl/*";
//	str0 = "okjsdlk";
	str1 = "alkjfsldjfDFAKL";
	strNULL = "\0";
	ret = ft_str_is_alpha(str0);
	printf("%s\n", str0);
	printf("DEBE SER 0 → %d\n", ret);
	ret = ft_str_is_alpha(str1);
	printf("%s\n", str1);
	printf("DEBE SER 1 → %d\n", ret);
	ret = ft_str_is_alpha(strNULL);
	printf("(null string, empty outside partenthesis) %s\n", strNULL);
	printf("DEBE SER 1 → %d\n", ret);
}
