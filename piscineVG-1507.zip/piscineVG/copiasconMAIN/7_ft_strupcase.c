#include <stdio.h>
#include <unistd.h>
 
int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < 41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}

char	*ft_strupcase(char *str)
{
	unsigned int	i;
	int				isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = ft_str_is_alpha(&str[i]);
		if (isalpha == 1 && str[i] >= 61 && str[i] <= 0x7A)
		{ 
			str[i] -= 32; 
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char	str[] = "hola";
//	char	*upstr;

//	upstr = ft_strupcase(str);
	printf("%s\n", ft_strupcase(str));

	return (0);
}
