/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 14:53:48 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/15 15:11:15 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < 41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}

char	*ft_strupcase(char *str)
{
	unsigned int	i;
	int				isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = ft_str_is_alpha(&str[i]);
		if (isalpha == 1 && str[i] >= 61 && str[i] <= 0x7A)
		{
			str[i] -= 32;
		}
		i++;
	}
	return (str);
}
