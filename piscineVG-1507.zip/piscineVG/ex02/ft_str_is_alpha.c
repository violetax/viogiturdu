int	ft_str_is_alpha(char *str)
{
	unsigned int	i;
	unsigned char	isalpha;

	i = 0;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < 41 || isalpha > 0x7A)
			return (0);
		i++;
	}
	return (1);
}
