int

ft_strncmp(char *s1, char *s2, unsigned int n);
