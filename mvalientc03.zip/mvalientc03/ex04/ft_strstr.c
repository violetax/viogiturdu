/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 07:47:49 by mvalient          #+#    #+#             */
/*   Updated: 2022/07/20 15:52:17 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
char	*ft_strstr(char *str, char *to_find)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	if (to_find[j] == '\0')
		return (str);
	while (str[i] != '\0')
	{
		if (str[i] == to_find[j])
		{
			while (str[i] == to_find[j] || to_find[j] == '\0')
			{
				if (to_find[j] == '\0')
					return (&str[i - j]);
				i++;
				j++;
			}
		}
		i++;
	}
	return (0);
}

int main() {
//  char    str[] = "habia una vez un circo";;
//  char    to_find[] = "v";
//
//  printf("probando %s\n", to_find);
//  printf("to_find: %s\n", ft_strstr(str, to_find));
    char str[] = "hola molinete";
    char to_find[] = "ol";

    printf("%s", ft_strstr(str, to_find));
    return 0;
}
