/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 08:32:59 by mvalient          #+#    #+#             */
/*   Updated: 2022/07/20 16:14:00 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (dest[j] != '\0')
	{	
		j++;
	}
	while (src[i] != '\0')
	{
		if (j < size - 1)
		{
			dest[j] = src[i];
		}
		i++;
		j++;
	}
	dest[j - 1] = '\0';
	return (j);
}


int main()
{
    char src[100] = "amigo";
    char dest[100] = "hola!!!";

    printf("dest %s\n", dest);
    printf("dest %d\n", ft_strlcat(dest, src, 4));
}
