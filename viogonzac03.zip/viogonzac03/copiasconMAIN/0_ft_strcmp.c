#include <stdio.h>
int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
		i++;
	return (s1[i] - s2[i]);
}

int main(void)
{
	char			*s1;
	char			*s2;
	char			*s3;
	int				i;

	s1 = "HOLA uno dos y tres";
	s2 = "uno";
	s3 = "uno";
	
	i = ft_strcmp(s1, s2);
	printf("'%s' y '%s', retorna la diferencia de valor ascii entre\n el primer valor que difiere → %d\n", s1, s2, i);
	return (0);
}
