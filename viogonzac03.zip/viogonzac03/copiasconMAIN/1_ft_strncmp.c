#include <stdio.h>
int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0' && i < n)
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	if (i < n)
	{
		return (s1[i] - s2[i]);
	}
	return (0);
}

int main(void)
{
	char			*s1;
	char			*s2;
	char			*s3;
	int				i;

	s1 = "uno dos y tres";
	s2 = "unO";
	s3 = "uno";
	
	i = ft_strncmp(s1, s2, 3);
	printf("'%s' lo que pasa es mayor que '%s', retorna DIF + → %d\n", s1, s2, i);
	i = ft_strncmp(s2, s1, 5);
	printf("'%s' lo que pasa es mas pequeno que '%s', retorna DIF negativa → %d\n", s2, s1, i);
	i = ft_strncmp(s3, s2, 5);
	printf("'%s' lo que pasa es igual '%s', retorna '0' → %d\n", s2, s3, i);
	return (0);
}
