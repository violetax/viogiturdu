#include <unistd.h>
#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	i;
	char			*p;

	p = src; // hola

	i = 0;
	while (p[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}	
	dest[i] = '\0';

	return (dest);
}

int main() {

	char *src = "hola";
	char *dest = "\0";

	dest = ft_strcpy(dest,src);

return 0;
}
