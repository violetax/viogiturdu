#include <unistd.h>
#include <stdio.h>


char *ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	while (i <= n)
	{
		dest[i] = '\0';
		i++;
	}

	return (dest);
}




int main() {

	char			*str = "unastringmuylarga";
	char			*dest = "\0";
	unsigned int	n;

//	dest = str;
	n = 3;
//	dest = ft_strncpy(dest,str,n);
	printf("%s\n",dest);
	printf("%s\n",dest);


return 0;
}

