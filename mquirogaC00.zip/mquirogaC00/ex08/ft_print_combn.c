/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mquiroga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/03 08:44:46 by mquiroga          #+#    #+#             */
/*   Updated: 2022/07/03 16:55:33 by mquiroga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);
int	*	get_number(int n);
int	*	gen_number(int * number, int j);

void	ft_print_combn(int n)
{
	int *	number;
	int	j;

	j = n - 1;
	number = get_number(n);
	number = gen_number(number, j);
}

int *	get_number(int x)
{
	int	i;
	int	number[10];

	i = 0;
	while (i < x)
	{
		number[i] = i;
		i++;
	}
	return (number);
}

int	*	gen_number(int * number, int j)
{

	return (number);
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
