/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mquiroga <mquiroga@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/30 15:24:31 by mquiroga          #+#    #+#             */
/*   Updated: 2022/07/04 12:21:56 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_putchar(char c1, char c2, char c3, char c4);

void	ft_print_comb2(void)
{
	char	n1;
	char	n2;
	char	n3;
	char	n4;

	n1 = '0' - 1;
	while (++n1 <= '9')
	{
	n2 = '0' - 1;
		while (++n2 <= '9')
		{
		n3 = '0' - 1;
			while (++n3 <= '9')
			{
				n4 = '0' - 1;
				while (++n4 <= '9')
				{
					ft_putchar(n1, n2, n3, n4);
				}
			}
		}
	}
}

void	ft_putchar(char c1, char c2, char c3, char c4)
{
	if (c1 <= c3 && c2 <= c4)
	{
		if (!(c1 == c3 && c2 == c4))
		{
			write(1, &c1, 1);
			write(1, &c2, 1);
			write(1, " ", 1);
			write(1, &c3, 1);
			write(1, &c4, 1);
			if (!(c1 == '9' && c2 == '8' && c3 == '9' && c4 == '9'))
			{
				write(1, ", ", 2);
			}
		}
	}
}

int main () { 
	ft_print_comb2();
}
