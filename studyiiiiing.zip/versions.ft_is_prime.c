//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	while (nb % i != 0)
	{
		if (i > nb)
			break ;
		i++;
	}
	if (nb == i)
	{
		return (1);
	}
	return (0);
}

int	main(void)
{	
	printf("1 is prime? %d\n", ft_is_prime(1));
	printf("3 is iprime? %d\n", ft_is_prime(3));
	printf("18 is prime? %d\n", ft_is_prime(18));
	printf("19 is prime? %d\n", ft_is_prime(19));
	return (0);
}
//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	while (nb % i != 0)
	{
		if (i > nb)
			break ;
		i++;
	}
	if (nb == i)
	{
		return (1);
	}
	return (0);
}
//   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */

#include <stdio.h>

int	ft_is_prime(int nb)
{
	int	i;
	int	cont;

	if (nb <= 1)
		return (0);
	i = 2;
	cont = 1;
	while (i <= nb / 2 && cont)
	{
		if (nb % i == 0)
			cont = 0;
		i++;
	}
	return (cont);
}

int	main(void)
{
	int	i;

	for (i = -1; i < 100; i++)
	{
		if (ft_is_prime(i))
			printf("%d es primo\n", i);
	}
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

int	ft_is_prime(int nb)
{
	int	i;

	if (nb < 2)
		return (0);
	i = 1;
	while (++i < nb)
	{
		if (nb % i == 0)
			return (0);
	}
	return (1);
}
