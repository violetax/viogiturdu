//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	res;

	i = 0;
	res = 1;
	if (nb < 0)
		return (0);
	if (power == 0)
		return (1);
	while (i++ < power)
		res = res * nb;
	return (res);
}

int	main(void)
{
	printf("2^2 = %d\n", ft_iterative_power(2, 2));
	printf("3^3 = %d\n", ft_iterative_power(3, 3));
	printf("4^4 = %d\n", ft_iterative_power(4, 4));
	printf("8^2 = %d\n", ft_iterative_power(8, 2));
	return (0);
}
//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	res;

	i = 0;
	res = 1;
	if (nb < 0)
		return (0);
	if (power == 0)
		return (1);
	while (i++ < power)
		res = res * nb;
	return (res);
}
//   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */

#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	pow;
	int	i;

	if (power < 0)
		return (0);
	if (power < 1)
		return (1);
	pow = 1;
	i = 1;
	while (i <= power)
	{
		pow *= nb;
		i++;
	}
	return (pow);
}

int	main(void)
{
	int	i;
	int	j;

	i = 3;
	j = 2;
	for (i = -5;i < 5; i++)
		for (j= -5;j < 5; j++)
			printf("%d elevado a %d es: %d\n", i, j, ft_iterative_power(i,j));
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

int	ft_iterative_power(int nb, int power)
{
	int	res;

	if (power == 0)
		return (1);
	else if (power < 0)
		return (0);
	res = 1;
	while (power >= 1)
	{
		res = nb * res;
		power--;
	}
	return (res);
}
