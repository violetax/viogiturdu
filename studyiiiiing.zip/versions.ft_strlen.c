//   By: jperez <jperez@student.42.fr>              +#+  +:+       +#+        */

#include<stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	main(void)
{
	char	*string;
	int		n;

	string = "hola";
	n = ft_strlen(string);
	printf("%d", n);
	return (0);
}
