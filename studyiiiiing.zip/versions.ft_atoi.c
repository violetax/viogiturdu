//   By: jperez <jperez@student.42.fr>              +#+  +:+       +#+        */

#include<stdio.h>

int	ft_int_value(char *str)
{
	int	i;
	int	cont;

	cont = 0;
	i = 0;
	while (str[i])
	{
		if (str[i] == '-')
			cont ++;
		i++;
	}
	if (cont % 2 == 0)
		return (0);
	else
		return (1);
}

int	ft_atoi(char *str)
{
	int	num;
	int	i;
	int	j;

	i = 0;
	num = 1;
	while (str[i] && num == 1)
	{
		if ('1' <= str[i] && str[i] <= '9')
		{
			num = num * (str[i] - '0');
			j = i + 1;
			while ('1' <= str[j] && str[j] <= '9')
			{
				num = num * 10 + (str[j] - '0');
				j++;
			}
		}
		i++;
	}
	if (ft_int_value(str) == 1)
		num = num * (-1);
	return (num);
}

int	main(void)
{
	char	char1[] = "-----8A644d8";
	int		num1;

	num1 = ft_atoi(char1);
	printf("%d", num1);
	return (0);
}
