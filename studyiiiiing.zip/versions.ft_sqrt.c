//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	if (nb == 1)
		return (1);
	while (i < nb / 2)
	{
		if (i * i == nb)
			return (i);
		i++;
	}
	return (0);
}

int	main(void)
{	
	printf("SQRT 16: %d\n", ft_sqrt(16));
	printf("SQRT 25: %d\n", ft_sqrt(25));
	printf("SQRT 64: %d\n", ft_sqrt(64));
	printf("SQRT -1: %d\n", ft_sqrt(-1));
	printf("SQRT 1: %d\n", ft_sqrt(1));
	return (0);
}
//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	if (nb == 1)
		return (1);
	while (i < nb / 2)
	{
		if (i * i == nb)
			return (i);
		i++;
	}
	return (0);
}
//   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	while (i * i <= nb)
	{
		if (i * i == nb)
			return (i);
		i++;
	}
	return (0);
}

int	main(void)
{
	int	sqr;
	int	i;

	for (i = -1; i < 50000; i++)
	{
		sqr = ft_sqrt(i);
		if (sqr)
			printf("La raiz cuadrada de %d es: %d\n", i, sqr);
	}
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	while (++i < nb)
	{
		if ((i * i) == nb)
			return (i);
	}
	return (0);
}
