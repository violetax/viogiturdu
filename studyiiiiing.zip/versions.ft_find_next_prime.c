//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	while (nb % i != 0)
	{
		if (i > nb)
			break ;
		i++;
	}
	if (nb == i)
	{
		return (1);
	}
	return (0);
}

int	ft_find_next_prime(int nb)
{
	int	i;

	i = 2;
	while (nb < 214748647)
	{
		if (ft_is_prime(nb))
			return (nb);
		nb++;
	}
	return (0);
}
//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	while (nb % i != 0)
	{
		if (i > nb)
			break ;
		i++;
	}
	if (nb == i)
	{
		return (1);
	}
	return (0);
}

int	ft_find_next_prime(int nb)
{
	int	i;

	i = 2;
	while (nb < 214748647)
	{
		if (ft_is_prime(nb))
			return (nb);
		nb++;
	}
	return (0);
}

int	main(void)
{
	printf("1, next prime is: %d\n", ft_find_next_prime(1));
	printf("6, next prime is: %d\n", ft_find_next_prime(6));
	printf("3, next prime is: %d\n", ft_find_next_prime(3));
	printf("12, next prime is: %d\n", ft_find_next_prime(12));
	printf("40, next prime is: %d\n", ft_find_next_prime(40));
	printf("120, next prime is: %d\n", ft_find_next_prime(120));
	printf("431, next prime is: %d\n", ft_find_next_prime(431));
	return (0);
}
//   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */

#include <stdio.h>

int	ft_is_prime(int nb);

int	ft_find_next_prime(int nb)
{
	int	i;

	i = nb;
	while (i < 2147483647)
	{
		if (ft_is_prime(i))
			return (i);
		i++;
	}
	return (0);
}

int	ft_is_prime(int nb)
{
	int	i;
	int	cont;

	if (nb <= 1)
		return (0);
	i = 2;
	cont = 1;
	while (i <= nb / 2 && cont)
	{
		if (nb % i == 0)
			cont = 0;
		i++;
	}
	return (cont);
}

int	main(void)
{
	int	i;

	for (i = 1000000111; i < 2000000000; i += 20)
	{
		printf("El siguiente primo de %d es %d\n", i, ft_find_next_prime(i));
	}
	return (0);
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

int	ft_is_prime(int nb)
{
	int	i;

	if (nb < 2)
		return (0);
	i = 1;
	while (++i < nb)
	{
		if (nb % i == 0)
			return (0);
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	while (1)
	{
		if (ft_is_prime(nb) == 1)
			return (nb);
		nb++;
	}
	return (0);
}
