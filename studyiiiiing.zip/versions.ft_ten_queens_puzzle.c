//   By: eescubi <eescubi@student.42.fr>            +#+  +:+       +#+        */

#include <stdio.h>
#include <unistd.h>
#define N 10

void	ft_ten_queens_puzzle_rec(int sol[N], int size, long *nsol);
void	ft_print_sol(int sol[N]);
int		ft_queen_eaten(int sol[N], int size);

int	ft_ten_queens_puzzle(void)
{
	long	n;
	int		sol[N];

	n = 0;
	ft_ten_queens_puzzle_rec(sol, 0, &n);
	return (n);
}

int	main(void)
{
	printf("Soluciones: %d\n", ft_ten_queens_puzzle());
	return (0);
}

void	ft_ten_queens_puzzle_rec(int sol[N], int size, long *nsol)
{
	int	i;

	if (size == N)
	{
		ft_print_sol(sol);
		*nsol = *nsol + 1;
	}
	else
	{
		i = 0;
		while (i < N)
		{
			sol[size] = i;
			if (!ft_queen_eaten(sol, size))
			{
				ft_ten_queens_puzzle_rec(sol, size + 1, nsol);
			}
		i++;
		}
	}
}

void	ft_print_sol(int sol[N])
{
	int		i;
	char	c;

	i = 0;
	while (i < N)
	{
		c = sol[i] + 48;
		write(1, &c, 1);
		i++;
	}
	write(1, &"\n", 1);
}

int	ft_queen_eaten(int sol[N], int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if ((sol[size] == sol[i])
			|| ((sol[size] == sol[i] + (size - i))
				|| (sol[size] == sol[i] - (size - i))))
		{
			return (1);
		}
		i++;
	}
	return (0);
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

void	ft_putnbr(int n)
{
	char	c;

	c = n - '0';
	write(1, &c, 1);
}

void	ft_nl(void)
{
	write(1, " \n", 2);
}

int	ft_ten_queens_puzzle(void)
{
	int	j;
	int	i;

	i = -1;
	while (++i <= 9)
	{
		j = 0;
		ft_putnbr(i, j);
		ft_nl();
	}
}
