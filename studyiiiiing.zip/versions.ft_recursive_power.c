//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

#include <stdio.h>

int	ft_recursive_power(int nb, int power)
{
	int	i;

	i = 0;
	if (nb < 0)
		return (0);
	else if (power == 0)
		return (1);
	else if (power > 0)
		return (nb * ft_recursive_power(nb, power -1));
	return (nb);
}

int	main(void)
{
	printf("2^2 = %d\n", ft_recursive_power(2, 2));
	printf("3^3 = %d\n", ft_recursive_power(3, 3));
	printf("4^4 = %d\n", ft_recursive_power(4, 4));
	printf("8^2 = %d\n", ft_recursive_power(8, 2));
	return (0);
}
//   By: mvalient <marvin@42.fr>                    +#+  +:+       +#+        */

int	ft_recursive_power(int nb, int power)
{
	int	i;

	i = 0;
	if (nb < 0)
		return (0);
	else if (power == 0)
		return (1);
	else if (power > 0)
		return (nb * ft_recursive_power(nb, power -1));
	return (nb);
}
//   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */

#include <stdio.h>

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power < 1)
		return (1);
	return (nb * ft_recursive_power(nb, power - 1));
}

int	main(void)
{
	int	i;
	int	j;
	for (i = -5;i < 5; i++)
		for (j= -5;j < 5; j++)
			printf("%d elevado a %d es: %d\n", i, j, ft_recursive_power(i,j));
}
//   By: isojo-go <isojo-go@student.42urduli>       +#+  +:+       +#+        */

int	ft_recursive_power(int nb, int power)
{
	if (power == 0)
		return (1);
	if (power > 0)
		return (nb * ft_recursive_power(nb, power - 1));
	return (0);
}
