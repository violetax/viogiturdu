//   By: jperez <jperez@student.42.fr>              +#+  +:+       +#+        */

#include<unistd.h>
#include<stdio.h>

void	ft_trasnfor_number(int nbr, int lenght)
{
	char	num;
	char	*hex;

	hex = "0123456789ABCDEF";
	if (lenght == 16)
		num = hex[nbr % 16];
	else
		num = nbr % lenght + '0';
	if (nbr > lenght - 1)
		ft_trasnfor_number(nbr / lenght, lenght);
	write(1, &num, 1);
}

int	check_entry(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (1);
			j++;
		}
		if (base[i] == '+' || base[j] == '-')
			return (1);
		i++;
	}
	if (i < 2)
		return (1);
	return (0);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	i;

	if (check_entry(base) == 0)
	{
		if (nbr < 0)
		{
			write(1, "-", 1);
			nbr = nbr * -1;
		}
		i = 0;
		while (base[i])
			i++;
		ft_trasnfor_number(nbr, i);
	}
}

int	main(void)
{
	ft_putnbr_base(-28, "0123456789ABCDEF");
	return (0);
}
