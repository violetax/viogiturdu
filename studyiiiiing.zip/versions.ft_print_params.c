//   By: alejarod <alejarod@student.42.fr>          +#+  +:+       +#+        */

#include<unistd.h>

int	main(int argc, char **argv)
{
	int	c;
	int	i;

	c = 1;
	while (c < argc)
	{
		i = 0;
		while (argv[c][i] != '\0')
		{
			write (1, &argv[c][i], 1);
			i++;
		}
	c++;
		write(1, "\n", 1);
	}
}
//   By: ghurtado <ghurtado@student.42.fr>          +#+  +:+       +#+        */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	i;
	int	j;

	i = 0;
	while (argc > ++i)
	{
		j = -1;
		while (argv[i][++j])
			write(1, &argv[i][j], 1);
		write(1, "\n", 1);
	}
	return (0);
}
