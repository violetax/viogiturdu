/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_group.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 16:18:04 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/17 16:18:05 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "rush-02.h"

void	ft_print_group(char ***dict, int size[3], char *num, int block)
{
	int	i;

	i =  (3 * (block - 1)) + size[0];
	while (i < (3 * (block - 1)) + size[0] + 3)
	{
		write (1, &num[i], 1);
		i++;
	}
	printf(" Group: %d\n", block);
}
