/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_write_values.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 19:48:09 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 19:48:12 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*     vars[0] = numword                                                      */
/*     vars[1] = line                                                         */
/*     vars[2] = i                                                            */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int	ft_write_values(char ***dict, int vars[3], char c, int *numinitfin)
{
	int	incorrect;

	incorrect = 0;
	if (c == '\n')
	{
		vars[0] = 0;
		vars[1]++;
		vars[2] = 0;
		numinitfin[0] = 0;
		numinitfin[1] = 0;
	}
	else
	{
		if (c == ':')
		{
			vars[0] = 1;
			vars[2] = 0;
			numinitfin[0] = 0;
		}
		else
		{
			incorrect = ft_dict_error(dict, vars, c, numinitfin);
		}	
	}
	return (incorrect);
}
