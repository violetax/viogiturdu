/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rush02.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 12:04:27 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 12:04:29 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

void	ft_rush02(char *name, char *num)
{
	int		size[3];

	size[0] = ft_sizecalc(name, &size[1], &size[2]);
	if (size[0] < 41 || ft_alloc_mem(name, size, num))
	{
		ft_print_msg("Dict Error\n");
		return ;
	}
	//ft_free_mem(numbers, lits, dsize);
	//Esto va al final, pero dentro de la funcion ft_alloc_mem
}