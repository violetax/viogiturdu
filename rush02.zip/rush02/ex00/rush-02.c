/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 10:28:54 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 10:28:56 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int	main(int nargs, char **args)
{
	char	*dictname;
	char	*numtowrite;

	if (nargs < 2 || nargs > 3)
	{
		ft_print_msg("Error\n");
		return (0);
	}
	if (nargs == 2)
	{
		dictname = "numbers.dict";
		numtowrite = args[1];
	}
	else
	{
		dictname = args[1];
		numtowrite = args[2];
	}
	if (!ft_valid_number(numtowrite))
	{
		ft_print_msg("Error\n");
		return (0);
	}
	ft_rush02(dictname, numtowrite);
	//printf("El numero a escribir es: %s\n", numtowrite);
	return (0);
}
