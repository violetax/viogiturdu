/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_load_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 12:38:07 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 12:38:08 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*     vars[0] = numword                                                      */
/*     vars[1] = line                                                         */
/*     vars[2] = i                                                            */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int	ft_load_file(char *name, char ***dict, int size[3], char *num)
{
	int		file;
	char	c;
	int		vars[3];
	int		incorrect;
	int		numinitfin[2];

	vars[0] = 0;
	vars[1] = 0;
	vars[2] = 0;
	incorrect = 0;
	numinitfin[0] = 0;
	numinitfin[1] = 0;
	file = open(name, 0);
	while (read (file, &c, 1) && !incorrect)
	{
		incorrect = ft_write_values(dict, vars, c, numinitfin);
	}
	close (file);
	if (!incorrect)
	{
		ft_trim_strings(dict, size);
		ft_print_number(dict, size, num);
		//ft_print_dic(dict, size);
	}	
	ft_free_mem(dict, size);
	return (incorrect);
}
