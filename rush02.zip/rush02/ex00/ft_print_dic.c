/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_dic.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 15:30:16 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 15:30:18 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

void	ft_print_dic(char ***dict, int size[3])
{
	int	j;
	int	i;

	for (i = 0; i < size[0] ; i++)
	{
		for (j = 0; j < size[2]; j++)
		{
			if (dict[0][i][j] != '\0')
			{
				printf("%c", dict[0][i][j]);
			}
			else
			{
				printf("-");
			}
				
		}
		printf(":");
		for (j = 0; j < size[1]; j++)
		{
			if (dict[1][i][j] != '\0')
			{
				printf("%c", dict[1][i][j]);
			}
			else
			{
				printf("-");
			}
		}
		printf("\n");
	}
}
