/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_dict.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmallaga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 13:59:34 by jmallaga          #+#    #+#             */
/*   Updated: 2022/07/17 19:14:56 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(char *a, char *b)
{
	char    aux;

	aux = *a;
	*a = *b;
	*b = aux;
}
void	ft_sort_dict(char ***dict, int size[3])
{
	int	i;

	i = 0;
	while (i < size[0])
	{
		if (size[i] > size[i + 1])
		{
			ft_swap(dict[0][i], dict[0][i + 1]);
			i = 0;
		}
		else
			i++;
	}
}
