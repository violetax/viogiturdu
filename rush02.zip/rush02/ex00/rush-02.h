/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-02.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmallaga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 10:09:10 by jmallaga          #+#    #+#             */
/*   Updated: 2022/07/17 10:27:45 by jmallaga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH02_H
# define RUSH02_H

# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <fcntl.h>

void	ft_print_msg(char *msg);
void	ft_rush02(char *name, char *num);
int		ft_sizecalc(char *name, int *maxwidth, int *maxnumw);
int		ft_alloc_mem(char *name, int size[3], char *num);
int		ft_load_file(char *name, char ***dict, int size[3], char *num);
void	ft_free_mem(char ***dict, int size[3]);
void	ft_print_dic(char ***dict, int size[3]);
void	ft_init_mem(char ***dict, int size[3]);
int		ft_write_values(char ***dict, int vars[3], char c, int *numinit);
int		ft_dict_error(char ***dict, int vars[3], char c, int *numinitfin);
void	ft_check_line(char c, int vars[3], int *maxwidth, int *maxnumw);
void	ft_print_number(char ***dict, int size[3], char *num);
int		ft_valid_number(char *num);
void	ft_trim_strings(char ***dict, int size[3]);
int		ft_strlen(char *num);
void	ft_print_rest(char ***dict, int size[3], char *num, int block);
void	ft_print_group(char ***dict, int size[3], char *num, int block);

#endif
