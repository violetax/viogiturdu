/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_rest.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 16:15:09 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/17 16:15:11 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "rush-02.h"

void ft_print_rest(char ***dict, int size[3], char *num, int block)
{
	int	i;

	i = 0;
	while (i < size[0])
	{
		write (1, &num[i], 1);
		i++;
	}
	printf("RestBl: %d\n", block);

}
