/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dict_error.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 11:20:22 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/17 11:20:25 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int		ft_dict_error(char ***dict, int vars[3], char c, int *numinitfin)
{
	if (vars[0] == 0 && numinitfin[0] == 0 && !(c >= '0' && c <= '9'))
	{
		return (1);
	}
	if ((vars[0] == 0 && numinitfin[0] == 1 && !(c >= '0' && c <= '9'))
		&& (c != ' '))
	{
		return (1);
	}
	if (vars[0] == 0 && (c >= '0' && c <= '9'))
	{
		if (numinitfin[1] == 1)
		{
			return (1);
		}
		numinitfin[0] = 1;
		dict[vars[0]][vars[1]][vars[2]] = c;
	 	vars[2]++;
	}
	if (vars[0] == 0 && c == ' ')
	{
		numinitfin[1] = 1;
	}
	if (vars[0] == 1 && c != ' ')
	{
		numinitfin[0] = 1;
	}
	if (vars[0] == 1 && numinitfin[0] == 1)
	{
		dict[vars[0]][vars[1]][vars[2]] = c;
	 	vars[2]++;
	}
	
	// if ((c >= 'a' && c <= 'z')
	// 	|| ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')))
	// {
	// 	dict[vars[0]][vars[1]][vars[2]] = c;
	// 	vars[2]++;
	// }
	return(0);
}
