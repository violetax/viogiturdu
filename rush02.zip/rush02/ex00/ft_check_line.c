/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 20:20:23 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 20:20:25 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_check_line(char c, int vars[3], int *maxwidth, int *maxnumw)
{
	if ((c != '\n' && c != ':'))
		vars[2]++;
	if (c == '\n')
	{
		if (vars[2] > *maxwidth)
			*maxwidth = vars[2];
		vars[2] = 0;
		vars[1]++;
	}
	if (c == ':')
	{
		if (vars[2] > *maxnumw)
			*maxnumw = vars[2];
		vars[2] = 0;
	}
}
