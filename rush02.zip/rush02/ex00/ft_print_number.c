/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_number.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 13:53:25 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/17 13:53:27 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "rush-02.h"

void	ft_print_number(char ***dict, int size[3], char *num)
{
	int		i;

	size[2] = ft_strlen(num);
	size[0] = size[2] % 3;
	ft_print_rest(dict, size, num, 0);
	i = size[2] % 3;
	while (i < size[2])
	{
		ft_print_group(dict, size, num, i / 3 + 1);
		i+=3;
	}
}
