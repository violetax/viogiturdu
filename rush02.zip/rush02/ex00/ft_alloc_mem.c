/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_alloc_mem.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 12:31:23 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 12:31:24 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int	ft_alloc_mem(char *name, int size[3], char *num)
{
	int		i;
	char	***dict;

	dict = malloc(sizeof(char **) * 2);
	dict[0] = malloc(sizeof(char *) * size[0]);
	dict[1] = malloc(sizeof(char *) * size[0]);
	i = 0;
	while (i < size[0])
	{
		dict[0][i] = malloc(sizeof(char) * size[2]);
		dict[1][i] = malloc(sizeof(char) * size[1]);
		i++;
	}
	ft_init_mem(dict, size);
	return (ft_load_file(name, dict, size, num));
}
