/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sizecalc.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eescubi <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 10:51:52 by eescubi           #+#    #+#             */
/*   Updated: 2022/07/16 10:51:55 by eescubi          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*     vars[0] = file                                                         */
/*     vars[1] = size                                                         */
/*     vars[2] = width                                                        */
/*                                                                            */
/* ************************************************************************** */

#include "rush-02.h"

int	ft_sizecalc(char *name, int *maxwidth, int *maxnumw)
{
	char	c;
	int		vars[3];

	vars[0] = open(name, 0);
	if (vars[0] == -1)
		return (0);
	vars[1] = 0;
	*maxwidth = 0;
	*maxnumw = 0;
	vars[2] = 0;
	while (read (vars[0], &c, 1))
	{
		ft_check_line(c, vars, maxwidth, maxnumw);
	}
	*maxwidth = *maxwidth + 1;
	*maxnumw = *maxnumw + 1;
	close (vars[0]);
	return (vars[1]);
}
