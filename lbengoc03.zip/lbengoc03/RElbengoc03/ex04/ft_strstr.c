/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbengoec <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 17:33:36 by lbengoec          #+#    #+#             */
/*   Updated: 2022/07/20 17:36:53 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	unsigned int	i;
	unsigned int	a;
	char			*dest;

	i = 0;
	a = 0;
	while (str[i] != '\0')
	{
		a = 0;
		while (str[i + a] == to_find[a])
		{
			if (to_find[a + 1] == '\0')
				return (&str[i]);
			a++;
		}
		i++;
	}
	return (0);
}

int main()
{
	char str[] = "hola molinete";
	char to_find[] = "ol";

	printf("%s", ft_strstr(str, to_find));
	return 0;
}
