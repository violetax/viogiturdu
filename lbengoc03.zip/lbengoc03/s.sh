#!/bin/bash

source Asksure.fu
source Opte.fu
source Continua.fu
 

#cfiles=( "ex00/ft_strcmp.c" "ex01/ft_strncmp.c" "ex02/ft_strcat.c" "ex03/ft_strncat.c" "ex04/ft_strstr.c" )
cfiles=( "ex03/ft_strncat.c" "ex04/ft_strstr.c" )

for cf in ${cfiles[@]} 
do
vim ${cf} 
continua
done
