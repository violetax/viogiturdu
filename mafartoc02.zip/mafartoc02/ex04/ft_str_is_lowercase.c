/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mafarto- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/06 13:44:42 by mafarto-          #+#    #+#             */
/*   Updated: 2022/07/13 09:12:30 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
 

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 'a' || str[i] > 'z')
			return (0);
		i++;
	}
	return (1);
}

int main ()
{
	char	*strminu = "lkadsljf";
	char	*strother = "SDKGP_0j66";
	int		ret;

	ret = ft_str_is_lowercase(strminu);
	printf("%s\n",strminu);
	printf("%d\n",ret);

	ret = ft_str_is_lowercase(strother);
	printf("%s\n",strother);
	printf("%d\n",ret);

	


}
