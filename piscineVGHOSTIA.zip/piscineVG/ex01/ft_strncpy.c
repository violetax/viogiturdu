/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 10:20:24 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/14 10:20:26 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	printf("PRE:\t%s\n", dest);
	i = 0;
	while (src[i] != '\0' && i <= n)
	{
		dest[i] = src[i];
		i++;
	}
	if (i > n)
	{
		while (src[i] != '\0')
		{
			dest[i] = '\0';
		}
	}
	printf("POST:\t%s\n", dest);
}

int	main(void)
{
	char	src[100];
	char	dest[100];

	src = "esto para copiarse";
	dest = "aqui se copia";
	ft_strncpy(dest, src);
	return (0);
}
