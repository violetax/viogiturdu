/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 10:54:45 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/14 12:58:42 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int		i;
	int		isalpha;
	int		range_min_hd;
	int		range_max_hd;

	i = 0;
	isalpha = 0;
	range_min_hd = 41;
	range_max_hd = 0x7A;
	while (str[i] != '\0')
	{
		isalpha = str[i];
		if (isalpha < range_min_hd || isalpha > range_max_hd)
		{
			return (0);
		}
		i++;
	}
	return (1);
}
