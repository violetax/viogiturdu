/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 15:08:37 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/14 16:30:36 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	i;
	int	isnumeric;
	int	range_min_hd;
	int	range_max_hd;

	isnumeric = 0;
	range_min_hd = 30;
	range_max_hd = 39;
	i = 0;
	while (str[i] != '\0')
	{
		isnumeric = str[i];
		if (isnumeric < range_min_hd || isnumeric > range_max_hd)
		{
			return (0);
		}
		i++;
	}
	return (1);
}
