/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 19:04:10 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/14 19:10:29 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int		i;
	int		range_max_f;
	char	*p;

	p = str;
	i = 0;
	range_max_f = 0xFF;
	while (p[0] != '\0')
	{
		i = str[i];
		if (i < 0 || i > range_max_f)
		{
			return (0);
		}
		i = 0;
		p++;
	}
	return (1);
}

int	main(void)
{
	char	*str0;
	char	*str1;
	char	*strnull;
	int		ret;

	str0 = "ka;':wfa]\ng[0;kl/*";
	str1 = "alkjfsldjfDFAKL";
	strnull = "\0";
	ret = ft_str_is_printable(str0);
	printf("%s\n", str0);
	printf("DEBE SER 0 → %d\n", ret);
	ret = ft_str_is_printable(str1);
	printf("%s\n", str1);
	printf("DEBE SER 1 → %d\n", ret);
	ret = ft_str_is_printable(strnull);
	printf("(null string, empty outside partenthesis) %s\n", strnull);
	printf("DEBE SER 1 → %d\n", ret);
}
