/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   9_ft_strcapitalize.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: viogonza <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 16:55:42 by viogonza          #+#    #+#             */
/*   Updated: 2022/07/13 16:55:42 by viogonza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

{
	int		i;
	bool	contsp;

	i = 0;
	while (str[i])
	{
		if (str[i] >= ' ' && str[i] <= '@' && str[i] >= '[' && str[i] <= 96)
			str[i] -= 32;
		if (str[i] > 123)
			str[i] - 32;
		if (i == 0 && str[i] > 'a' && str[i] < 'z')
			str[i] -= 32;
		else if (contsp == true && str[i] > 'a' && str[i] < 'z')
		{
			str[i] -= 32;
		}
		i++;
	}
	return (str);
}
int	main()
{
}
